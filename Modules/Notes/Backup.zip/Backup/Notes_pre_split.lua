local _, ns = ...
local SnailStuff = ns.SnailStuff

-- Window Sizing And Title
local BACKDROP_TEMPLATE = BackdropTemplateMixin and "BackdropTemplate" or nil
local WINDOW_TITLE = "Notes"
local WINDOW_TITLE_Y_OFFSET = -2
local WINDOW_DEFAULT_WIDTH = 760
local WINDOW_DEFAULT_HEIGHT = 560
local WINDOW_MIN_WIDTH = 540
local WINDOW_MIN_HEIGHT = 420
local WINDOW_SCREEN_MARGIN = 48

-- Tabs And Note Defaults
local MAX_NOTE_TABS = 3
local TAB_HEIGHT = 24
local TAB_SPACING = -18
local DEFAULT_NOTE_TITLE = "Untitled Note"
local DEFAULT_NOTE_BODY = ""
local NOTE_ID_PREFIX = "note-"
local NOTE_TITLE_MAX_LENGTH = 20
local NOTE_EXPORT_PREFIX = "SSNOTE:1:"
local NOTE_EXPORT_VERSION = 1
local BUILTIN_NOTES_GUIDE_ID = ns.NotesGuideData and ns.NotesGuideData.id or "builtin-notes-guide"
local BUILTIN_NOTES_GUIDE_UPDATED_AT = ns.NotesGuideData and ns.NotesGuideData.updatedAt or 1

-- Home Tab Layout
local HOME_HEADER_TOP_INSET = 0
local HOME_HEADER_SIDE_INSET = 8
local HOME_HEADER_COUNT_TOP_OFFSET = 3
local HOME_BUTTON_WIDTH = 84
local HOME_BUTTON_HEIGHT = 22
local HOME_HEADER_BUTTON_SPACING = 4

-- Home List Layout
local HOME_LIST_TOP_INSET = 32
local HOME_LIST_FRAME_INSET = 4
local HOME_LIST_BOTTOM_INSET = 10
local HOME_LIST_BACKDROP_BORDER_MARGIN = 3
local HOME_LIST_INNER_PADDING = 8
local HOME_LIST_SCROLLBAR_WIDTH = 12
local HOME_LIST_SCROLLBAR_RIGHT_PADDING = 9
local HOME_LIST_SCROLLBAR_TOTAL_WIDTH = HOME_LIST_SCROLLBAR_WIDTH + HOME_LIST_SCROLLBAR_RIGHT_PADDING
local HOME_ROW_HEIGHT = 32
local HOME_ROW_SPACING = 2
local HOME_ROW_TEXT_SIDE_INSET = 10
local HOME_ROW_TEXT_VERTICAL_OFFSET = 0
local HOME_ROW_TITLE_VERTICAL_OFFSET = -1
local HOME_ROW_BUILTIN_TITLE_CENTER_OFFSET_X = 0
local HOME_ROW_TIMESTAMP_RIGHT_INSET = 10
local HOME_ROW_TIMESTAMP_WIDTH = 126
local HOME_ROW_TITLE_TO_TIMESTAMP_SPACING = 12
local HOME_ROW_TITLE_FONT_SIZE = 15
local HOME_ROW_TIMESTAMP_FONT_SIZE = 11
local EMPTY_STATE_WIDTH = 320
local EMPTY_STATE_HEIGHT = 84
local EMPTY_STATE_MESSAGE_WIDTH = 260
local ROW_STRIDE = HOME_ROW_HEIGHT + HOME_ROW_SPACING

-- Row Action Menu
local ROW_MENU_WIDTH = 148
local ROW_MENU_BUTTON_HEIGHT = 22
local ROW_MENU_PADDING = 6
local ROW_MENU_SPACING = 2
local ROW_MENU_ANCHOR_X = -6
local ROW_MENU_ANCHOR_Y = -2
local ROW_MENU_BACKGROUND_TEXTURE = "Interface\\Buttons\\WHITE8x8"

-- Note Tab Layout
local NOTE_TAB_SIDE_INSET = 8
local NOTE_TAB_BOTTOM_INSET = 10
local NOTE_TAB_TOP_ROW_TOP_OFFSET = 2
local NOTE_TAB_TOP_ROW_HEIGHT = 28
local NOTE_TAB_TOP_ROW_TO_BODY_GAP = 8
local NOTE_TAB_DELETE_BUTTON_WIDTH = 84
local NOTE_TAB_MODE_BUTTON_WIDTH = 84
local NOTE_TAB_SAVE_BUTTON_WIDTH = 84
local NOTE_TAB_EXPORT_BUTTON_WIDTH = 84
local NOTE_TAB_TOP_CLOSE_BUTTON_SIZE = 38
local NOTE_TAB_TOP_CLOSE_BUTTON_SPACING = -2
local NOTE_TAB_TOP_ROW_CLOSE_BUTTON_RIGHT_INSET = -8
local NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_LEFT = 4
local NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_RIGHT = 4
local NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_TOP = 4
local NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_BOTTOM = 4
local NOTE_TAB_TITLE_WIDTH = 160
local NOTE_TAB_TITLE_TO_META_SPACING = 10
local NOTE_TAB_FIELD_INNER_X = 8
local NOTE_TAB_FIELD_INNER_Y = 6

-- Note Body Layout
local NOTE_TAB_BODY_MIN_CONTENT_HEIGHT = 120
local NOTE_TAB_BODY_INITIAL_VISIBLE_WIDTH = 280
local NOTE_TAB_BODY_EDIT_FONT_SIZE = 16
local NOTE_TAB_BODY_DIAGNOSTIC_LEFT_INSET = 8
local NOTE_TAB_BODY_DIAGNOSTIC_TOP_INSET = 8
local NOTE_TAB_BODY_DIAGNOSTIC_RIGHT_INSET = 8
local NOTE_TAB_BODY_DIAGNOSTIC_BOTTOM_INSET = 8

-- Note Body Background
local NOTE_TAB_BODY_BACKGROUND_ATLAS = "auctionhouse-background-buy-noncommodities-market"
local NOTE_TAB_BODY_BACKGROUND_COLOR = { 1.0, 1.0, 1.0, 1.0 }
local NOTE_TAB_BODY_BACKGROUND_FALLBACK_COLOR = { 0.05, 0.05, 0.05, 0.55 }

-- Note Body Scrollbar Layout
local NOTE_TAB_BODY_NATIVE_LEFT_INSET = NOTE_TAB_BODY_DIAGNOSTIC_LEFT_INSET
local NOTE_TAB_BODY_NATIVE_TOP_INSET = NOTE_TAB_BODY_DIAGNOSTIC_TOP_INSET
local NOTE_TAB_BODY_NATIVE_RIGHT_INSET = NOTE_TAB_BODY_DIAGNOSTIC_RIGHT_INSET
local NOTE_TAB_BODY_NATIVE_BOTTOM_INSET = NOTE_TAB_BODY_DIAGNOSTIC_BOTTOM_INSET
local NOTE_TAB_BODY_SCROLLBAR_WIDTH = 26
local NOTE_TAB_BODY_SCROLLBAR_X_OFFSET = 0
local NOTE_TAB_BODY_SCROLLBAR_LEFT_INSET = 0
local NOTE_TAB_BODY_SCROLLBAR_TOP_INSET = 12
local NOTE_TAB_BODY_SCROLLBAR_GAP = 0
local NOTE_TAB_BODY_SCROLLBAR_RIGHT_INSET = 24
local NOTE_TAB_BODY_SCROLLBAR_BOTTOM_INSET = 12
local NOTE_TAB_READ_TITLE_RIGHT_INSET = 12

-- Read View Fonts
local FONT_REGULAR = "Interface\\AddOns\\SnailStuff\\Media\\Fonts\\IBM-Plex-Sans\\IBMPlexSans-Medium.ttf"
local FONT_ITALIC = "Interface\\AddOns\\SnailStuff\\Media\\Fonts\\IBM-Plex-Sans\\IBMPlexSans-MediumItalic.ttf"
local FONT_BOLD = "Interface\\AddOns\\SnailStuff\\Media\\Fonts\\IBM-Plex-Sans\\IBMPlexSans-Bold.ttf"
local FONT_BOLDITALIC = "Interface\\AddOns\\SnailStuff\\Media\\Fonts\\IBM-Plex-Sans\\IBMPlexSans-BoldItalic.ttf"

-- Read View Renderer MD-Lite
local READ_LINE_FONT_SIZE = 16
local READ_HEADER1_FONT_SIZE = 46
local READ_HEADER2_FONT_SIZE = 34
local READ_HEADER3_FONT_SIZE = 24
local READ_BULLET_INDENT = 28
local READ_LINE_VERTICAL_SPACING = -10
local READ_HEADER_VERTICAL_SPACING = 0
local READ_POST_BULLET_BLOCK_SPACING = 4
local READ_BLANK_LINE_HEIGHT = 10
local READ_SEPARATOR_ROW_HEIGHT = 18
local READ_SEPARATOR_SIDE_INSET = 10
local READ_SEPARATOR_THICKNESS = 1
local READ_SEPARATOR_COLOR = { 0.65, 0.62, 0.56, 0.75 }
local READ_CODE_BACKGROUND_COLOR = { 0.02, 0.02, 0.02, 0.42 }
local READ_UNRESOLVED_ITEM_TOKEN_COLOR = { 1.0, 0.25, 0.25 }

-- Visual Colors And Textures
local HOME_LIST_BACKGROUND_ATLAS = "tradeskill-background-recipe-unlearned"
local HOME_LIST_BACKGROUND_COLOR = { 1.0, 1.0, 1.0, 1.00 }
local HOME_LIST_BORDER_COLOR = { 0.30, 0.30, 0.30, 0.55 }
local HOME_ROW_BACKGROUND_COLOR = { 0.04, 0.04, 0.04, 0.14 }
local HOME_ROW_HOVER_COLOR = { 0.45, 0.68, 1.0, 0.12 }
local HOME_ROW_SELECTED_COLOR = { 0.38, 0.62, 1.0, 0.22 }
local ROW_MENU_BACKGROUND_COLOR = { 0, 0, 0, 0.72 }
local ROW_MENU_BUTTON_HOVER_COLOR = HOME_ROW_HOVER_COLOR

-- Import / Export Dialog
local NOTE_TRANSFER_DIALOG_WIDTH = 560
local NOTE_TRANSFER_DIALOG_HEIGHT = 380
local NOTE_TRANSFER_DIALOG_BUTTON_WIDTH = 84
local NOTE_TRANSFER_DIALOG_BUTTON_HEIGHT = 22
local NOTE_TRANSFER_DIALOG_SIDE_INSET = 14
local NOTE_TRANSFER_DIALOG_TOP_INSET = 14
local NOTE_TRANSFER_DIALOG_BOTTOM_INSET = 14
local NOTE_TRANSFER_DIALOG_INSTRUCTIONS_TOP_GAP = 10
local NOTE_TRANSFER_DIALOG_BODY_TOP_GAP = 12
local NOTE_TRANSFER_DIALOG_STATUS_TOP_GAP = 8
local NOTE_TRANSFER_DIALOG_BUTTON_TOP_GAP = 12
local NOTE_TRANSFER_DIALOG_EDIT_INNER_X = 8
local NOTE_TRANSFER_DIALOG_EDIT_INNER_Y = 8

-- Module State
local module
local AceSerializer
local LibDeflate
local noteBodyScrollFrameSerial = 0

StaticPopupDialogs["SNAILSTUFF_NOTES_CONFIRM_DISCARD"] = {
    text = "You have unsaved changes. Discard them?",
    button1 = YES,
    button2 = NO,
    OnAccept = function(_, data)
        if data and data.onConfirm then
            data.onConfirm()
        end
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
}

StaticPopupDialogs["SNAILSTUFF_NOTES_TITLE_REQUIRED"] = {
    text = "Notes need a title.",
    button1 = OKAY,
    OnAccept = function(_, data)
        local tab = data and data.tab or nil
        local view = module and module.GetNoteTabEditView and module:GetNoteTabEditView(tab and tab.panel) or nil
        if view and view.titleInput then
            view.titleInput:SetFocus()
            if view.titleInput.HighlightText then
                view.titleInput:HighlightText()
            end
        end
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
}

StaticPopupDialogs["SNAILSTUFF_NOTES_CONFIRM_DELETE"] = {
    text = "Are you sure you want to delete your note?",
    button1 = YES,
    button2 = CANCEL,
    OnAccept = function(_, data)
        if data and data.noteId then
            module:DeleteNote(data.noteId)
        end
    end,
    timeout = 0,
    whileDead = 1,
    hideOnEscape = 1,
    preferredIndex = 3,
}

local function ClampNoteTitleLength(title)
    title = tostring(title or "")
    if string.len(title) > NOTE_TITLE_MAX_LENGTH then
        return string.sub(title, 1, NOTE_TITLE_MAX_LENGTH)
    end

    return title
end

local function NormalizeNoteTitle(title)
    title = ClampNoteTitleLength(title)
    if title == "" then
        return DEFAULT_NOTE_TITLE
    end

    return title
end

local function TrimNoteTitle(title)
    title = tostring(title or "")
    title = string.gsub(title, "^%s+", "")
    title = string.gsub(title, "%s+$", "")
    return ClampNoteTitleLength(title)
end

local function ClampImportTimestamp(value)
    local number = tonumber(value)
    if not number or number <= 0 then
        return nil
    end

    return math.floor(number)
end

local function GetPrintableErrorMessage(message)
    local text = tostring(message or "Invalid note import string.")
    text = string.gsub(text, "[%c]+", " ")
    text = string.gsub(text, "%s+", " ")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    if text == "" then
        text = "Invalid note import string."
    end

    return text
end

local function ExtractItemIdFromItemLink(itemLink)
    local itemId = itemLink and string.match(itemLink, "item:(%d+)")
    return tonumber(itemId)
end

local function BuildSuffixedNoteTitle(baseTitle, suffixIndex)
    local suffix = string.format(" (%d)", tonumber(suffixIndex) or 1)
    local maxBaseLength = math.max(NOTE_TITLE_MAX_LENGTH - string.len(suffix), 0)
    local trimmedBase = string.sub(tostring(baseTitle or ""), 1, maxBaseLength)
    trimmedBase = string.gsub(trimmedBase, "%s+$", "")
    if trimmedBase == "" then
        trimmedBase = string.sub(DEFAULT_NOTE_TITLE, 1, maxBaseLength)
    end

    return trimmedBase .. suffix
end

local function ParseReadViewAtlasLine(rawLine)
    local lineText = tostring(rawLine or "")
    local atlasName, width, height = string.match(lineText, "^%[@atlas%s+([^%s%]]+)%s+(%d+)x(%d+)%s*%]$")
    if atlasName then
        return {
            rawText = lineText,
            atlasName = atlasName,
            width = tonumber(width),
            height = tonumber(height),
        }
    end

    atlasName = string.match(lineText, "^%[@atlas%s+([^%s%]]+)%s*%]$")
    if atlasName then
        return {
            rawText = lineText,
            atlasName = atlasName,
        }
    end

    return nil
end

local function IsReadViewCenteredBlockStart(rawLine)
    return tostring(rawLine or "") == "[c]"
end

local function IsReadViewCenteredBlockEnd(rawLine)
    return tostring(rawLine or "") == "[/c]"
end

local function IsReadViewCodeBlockStart(rawLine)
    return tostring(rawLine or "") == "[code]"
end

local function IsReadViewCodeBlockEnd(rawLine)
    return tostring(rawLine or "") == "[/code]"
end

local function SplitNoteBodyIntoLines(bodyText)
    local text = tostring(bodyText or "")
    local normalizedText = string.gsub(text, "\r\n", "\n")
    normalizedText = string.gsub(normalizedText, "\r", "\n")

    local lines = {}
    if normalizedText == "" then
        lines[1] = ""
        return lines
    end

    for line in string.gmatch(normalizedText .. "\n", "(.-)\n") do
        lines[#lines + 1] = line
    end

    return lines
end

local function ClassifyReadViewLine(rawLine)
    local lineText = tostring(rawLine or "")

    if lineText == "" then
        return "blank", ""
    end

    if string.match(lineText, "^###%s+") then
        return "h3", string.gsub(lineText, "^###%s+", "", 1)
    end

    if string.match(lineText, "^##%s+") then
        return "h2", string.gsub(lineText, "^##%s+", "", 1)
    end

    if string.match(lineText, "^#%s+") then
        return "h1", string.gsub(lineText, "^#%s+", "", 1)
    end

    if string.match(lineText, "^%-%s+") then
        return "bullet", string.gsub(lineText, "^%-%s+", "", 1)
    end

    if lineText == "---" then
        return "separator", ""
    end

    local atlasData = ParseReadViewAtlasLine(lineText)
    if atlasData then
        return "atlas", atlasData
    end

    if string.match(lineText, "^%*%*_.+_%*%*$") then
        local innerText = string.gsub(string.gsub(lineText, "^%*%*_", "", 1), "_%*%*$", "", 1)
        return "bolditalic", innerText
    end

    if string.match(lineText, "^_%*%*.+%*%*_$") then
        local innerText = string.gsub(string.gsub(lineText, "^_%*%*", "", 1), "%*%*_$", "", 1)
        return "bolditalic", innerText
    end

    if string.match(lineText, "^%*%*.+%*%*$") then
        return "bold", string.gsub(string.gsub(lineText, "^%*%*", "", 1), "%*%*$", "", 1)
    end

    if string.match(lineText, "^_.+_$") then
        return "italic", string.gsub(string.gsub(lineText, "^_", "", 1), "_$", "", 1)
    end

    return "plain", lineText
end

local function ParseReadViewInlineSegments(lineText)
    local text = tostring(lineText or "")
    local segments = {}
    local searchStart = 1

    while searchStart <= string.len(text) do
        local tokenStart, tokenEnd, itemId = string.find(text, "%[(%d+)%]", searchStart)
        if not tokenStart then
            break
        end

        if tokenStart > searchStart then
            segments[#segments + 1] = {
                kind = "text",
                text = string.sub(text, searchStart, tokenStart - 1),
            }
        end

        segments[#segments + 1] = {
            kind = "itemToken",
            text = string.sub(text, tokenStart, tokenEnd),
            itemId = itemId,
        }

        searchStart = tokenEnd + 1
    end

    if searchStart <= string.len(text) then
        segments[#segments + 1] = {
            kind = "text",
            text = string.sub(text, searchStart),
        }
    end

    if #segments == 0 then
        segments[1] = {
            kind = "text",
            text = text,
        }
    end

    return segments
end

local function GetSafeWindowScreenBounds()
    local parentWidth = UIParent and UIParent:GetWidth() or WINDOW_DEFAULT_WIDTH
    local parentHeight = UIParent and UIParent:GetHeight() or WINDOW_DEFAULT_HEIGHT
    local maxWidth = math.max(math.floor(parentWidth - (WINDOW_SCREEN_MARGIN * 2)), WINDOW_MIN_WIDTH)
    local maxHeight = math.max(math.floor(parentHeight - (WINDOW_SCREEN_MARGIN * 2)), WINDOW_MIN_HEIGHT)
    return maxWidth, maxHeight
end

local function ClampWindowSize(width, height)
    width = tonumber(width) or WINDOW_DEFAULT_WIDTH
    height = tonumber(height) or WINDOW_DEFAULT_HEIGHT
    local maxWidth, maxHeight = GetSafeWindowScreenBounds()

    width = math.max(WINDOW_MIN_WIDTH, math.min(math.floor(width + 0.5), maxWidth))
    height = math.max(WINDOW_MIN_HEIGHT, math.min(math.floor(height + 0.5), maxHeight))

    return width, height
end

local function ClampHomeWindowSize(width, height)
    local _, clampedHeight = ClampWindowSize(WINDOW_MIN_WIDTH, height)
    return WINDOW_MIN_WIDTH, clampedHeight
end

local function CompactCheckboxRow(row)
    if not row or not row.check or not row.label then
        return
    end

    row:SetHeight(30)
    if row.description then
        row.description:Hide()
    end

    row.check:ClearAllPoints()
    row.check:SetPoint("LEFT", 0, 0)

    row.label:ClearAllPoints()
    row.label:SetPoint("LEFT", row.check, "RIGHT", 6, 1)
    row.label:SetPoint("RIGHT", row, "RIGHT", 0, 0)
    row.label:SetJustifyV("MIDDLE")
end

local function AttachTooltip(frame, title, text)
    if not frame or not title then
        return
    end

    frame:EnableMouse(true)
    frame:SetScript("OnEnter", function(selfFrame)
        GameTooltip:SetOwner(selfFrame, "ANCHOR_RIGHT")
        GameTooltip:SetText(title, 1, 0.82, 0)
        if text and text ~= "" then
            GameTooltip:AddLine(text, 0.92, 0.88, 0.80, true)
        end
        GameTooltip:Show()
    end)
    frame:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
end

local function CreateSolidTexture(parent, layer, color)
    local texture = parent:CreateTexture(nil, layer or "BACKGROUND")
    texture:SetTexture("Interface\\Buttons\\WHITE8x8")
    texture:SetVertexColor(unpack(color))
    return texture
end

local function CreateBackdropFrame(parent, includeBackground)
    local frame = CreateFrame("Frame", nil, parent, BACKDROP_TEMPLATE)
    if frame.SetBackdrop then
        frame:SetBackdrop({
            bgFile = includeBackground and "Interface\\Tooltips\\UI-Tooltip-Background" or nil,
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            tile = true,
            tileSize = 16,
            edgeSize = 12,
            insets = { left = 3, right = 3, top = 3, bottom = 3 },
        })
    end
    return frame
end

local function GetDayStartTimestamp(value)
    local dateTable = date("*t", value or time())
    return time({
        year = dateTable.year,
        month = dateTable.month,
        day = dateTable.day,
        hour = 0,
        min = 0,
        sec = 0,
    })
end

local function FormatSmartTimestamp(timestamp, createdTimestamp)
    local safeTimestamp = tonumber(timestamp) or tonumber(createdTimestamp) or time()
    local safeCreated = tonumber(createdTimestamp) or safeTimestamp
    local prefix = safeTimestamp > safeCreated and "Updated" or "Created"

    local now = time()
    local dayStart = GetDayStartTimestamp(now)
    local targetDayStart = GetDayStartTimestamp(safeTimestamp)
    local dayDelta = math.floor((dayStart - targetDayStart) / 86400)

    if dayDelta <= 0 then
        return string.format("%s today %s", prefix, date("%I:%M %p", safeTimestamp))
    end

    if dayDelta == 1 then
        return string.format("%s yesterday %s", prefix, date("%I:%M %p", safeTimestamp))
    end

    if dayDelta < 7 then
        return string.format("%s %s %s", prefix, date("%a", safeTimestamp), date("%I:%M %p", safeTimestamp))
    end

    return string.format("%s %s", prefix, date("%b %d, %Y", safeTimestamp))
end

module = SnailStuff:CreateModule("Notes", {
    displayName = "Notes",
    description = "A lightweight note window shell with Home and temporary note tabs.",
    order = 20,
    defaults = {
        enabled = true,
        window = {
            width = WINDOW_DEFAULT_WIDTH,
            homeWidth = WINDOW_MIN_WIDTH,
            noteWidth = WINDOW_DEFAULT_WIDTH,
            height = WINDOW_DEFAULT_HEIGHT,
            point = "CENTER",
            relativePoint = "CENTER",
            x = 0,
            y = 0,
        },
        notes = {
            nextId = 1,
            items = {},
        },
    },
    page = {
        key = "extras",
        title = "Extras",
        subtitle = "Small optional quality-of-life features that stay separate from the main Blizzard UI modules.",
        order = 40,
        build = function(page)
            local section = page:CreateSection("Notes", "")
            section:SetHeight(92)
            page:AnchorFlow(section, 12)
            section.description:Hide()
            section.contentArea:ClearAllPoints()
            section.contentArea:SetPoint("TOPLEFT", section.separator, "BOTTOMLEFT", 0, -10)
            section.contentArea:SetPoint("TOPRIGHT", section.separator, "BOTTOMRIGHT", 0, -10)
            section.contentArea:SetHeight(1)

            local enabledRow = page:CreateCheckbox("Enable Notes", "")
            CompactCheckboxRow(enabledRow)
            AttachTooltip(enabledRow, "Enable Notes", "Enables the SnailStuff Notes window and its slash commands.")
            page:AnchorSectionControl(section, enabledRow)
            enabledRow.check:SetScript("OnClick", function(check)
                SnailStuff:SetModuleEnabled(module.moduleName, check:GetChecked())
            end)

            page:FinalizeFlow(16)

            page.RefreshControls = function()
                local settings = module:GetSettings()
                if not settings then
                    return
                end

                enabledRow.check:SetChecked(settings.enabled ~= false)
            end
        end,
    },
})

function module:GetBuiltinNotes()
    return {
        {
            id = BUILTIN_NOTES_GUIDE_ID,
            title = ns.NotesGuideData and ns.NotesGuideData.title or "Notes Guide",
            body = ns.NotesGuideData and ns.NotesGuideData.body or DEFAULT_NOTE_BODY,
            createdAt = BUILTIN_NOTES_GUIDE_UPDATED_AT,
            updatedAt = BUILTIN_NOTES_GUIDE_UPDATED_AT,
            isBuiltin = true,
        },
    }
end

function module:IsBuiltinNoteId(noteId)
    return noteId == BUILTIN_NOTES_GUIDE_ID
end

function module:GetBuiltinNoteById(noteId)
    if not self:IsBuiltinNoteId(noteId) then
        return nil
    end

    for _, note in ipairs(self:GetBuiltinNotes()) do
        if note.id == noteId then
            return note
        end
    end

    return nil
end

function module:GetSettings()
    return SnailStuff:GetModuleSettings(self.moduleName)
end

function module:GetWindowSettings()
    local settings = self:GetSettings()
    settings.window = settings.window or {}
    settings.window.width = tonumber(settings.window.width) or WINDOW_DEFAULT_WIDTH
    settings.window.homeWidth = tonumber(settings.window.homeWidth) or WINDOW_MIN_WIDTH
    settings.window.noteWidth = tonumber(settings.window.noteWidth) or WINDOW_DEFAULT_WIDTH
    return settings.window
end

function module:GetActiveWindowWidthSettingKey()
    if self:IsHomeTabActive() then
        return "homeWidth"
    end

    return "noteWidth"
end

function module:GetActiveWindowWidth(settings)
    settings = settings or self:GetWindowSettings()
    local widthKey = self:GetActiveWindowWidthSettingKey()
    return tonumber(settings[widthKey]) or tonumber(settings.width) or WINDOW_DEFAULT_WIDTH
end

function module:GetNoteStore()
    local settings = self:GetSettings()
    settings.notes = settings.notes or {}
    settings.notes.nextId = tonumber(settings.notes.nextId) or 1
    settings.notes.items = settings.notes.items or {}
    return settings.notes
end

function module:GetNotesTable()
    return self:GetNoteStore().items
end

function module:GetOrderedNotes()
    local orderedNotes = {}

    for _, note in ipairs(self:GetBuiltinNotes()) do
        orderedNotes[#orderedNotes + 1] = note
    end

    for _, note in pairs(self:GetNotesTable()) do
        orderedNotes[#orderedNotes + 1] = note
    end

    table.sort(orderedNotes, function(left, right)
        if left.isBuiltin ~= right.isBuiltin then
            return left.isBuiltin and true or false
        end

        local leftUpdated = tonumber(left.updatedAt) or tonumber(left.createdAt) or 0
        local rightUpdated = tonumber(right.updatedAt) or tonumber(right.createdAt) or 0
        if leftUpdated ~= rightUpdated then
            return leftUpdated > rightUpdated
        end

        local leftCreated = tonumber(left.createdAt) or 0
        local rightCreated = tonumber(right.createdAt) or 0
        if leftCreated ~= rightCreated then
            return leftCreated > rightCreated
        end

        return tostring(left.id or "") > tostring(right.id or "")
    end)

    return orderedNotes
end

function module:GetNoteById(noteId)
    if not noteId then
        return nil
    end

    local builtinNote = self:GetBuiltinNoteById(noteId)
    if builtinNote then
        return builtinNote
    end

    return self:GetNotesTable()[noteId]
end

function module:IsGloballyEnabled()
    return SnailStuff.db and SnailStuff.db.profile and SnailStuff.db.profile.enabled ~= false
end

function module:IsOperationalEnabled()
    local settings = self:GetSettings()
    return self:IsEnabled()
        and self:IsGloballyEnabled()
        and settings
        and settings.enabled ~= false
end

function module:IsHomeTabActive()
    return self.runtime and self.runtime.activeTabKey == "home"
end

function module:EnsureRuntime()
    if self.runtime then
        return
    end

    self.runtime = {
        frame = nil,
        activeTabKey = "home",
        tabs = {},
        orderedTabs = {},
        noteSlots = {},
        hoveredNoteId = nil,
        selectedNoteId = nil,
        rowActionMenu = nil,
        isListeningForReadItemInfo = false,
    }
end

function module:SaveWindowGeometry(frame)
    if not frame then
        return
    end

    local settings = self:GetWindowSettings()
    local width, height
    if self:IsHomeTabActive() then
        width, height = ClampHomeWindowSize(frame:GetWidth(), frame:GetHeight())
    else
        width, height = ClampWindowSize(frame:GetWidth(), frame:GetHeight())
    end
    settings[self:GetActiveWindowWidthSettingKey()] = width
    settings.width = width
    settings.height = height

    local point, _, relativePoint, x, y = frame:GetPoint(1)
    settings.point = point or "CENTER"
    settings.relativePoint = relativePoint or settings.point or "CENTER"
    settings.x = x or 0
    settings.y = y or 0
end

function module:UpdateWindowResizeBounds(frame)
    if not frame then
        return
    end

    local maxWidth, maxHeight = GetSafeWindowScreenBounds()
    if self:IsHomeTabActive() then
        maxWidth = math.max(math.min(WINDOW_MIN_WIDTH, maxWidth), WINDOW_MIN_WIDTH)
    end

    if frame.SetResizeBounds then
        frame:SetResizeBounds(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT, maxWidth, maxHeight)
    elseif frame.SetMaxResize then
        frame:SetMaxResize(maxWidth, maxHeight)
    end
end

function module:EnsureWindowGeometryIsReachable(frame)
    if not frame or not frame.GetLeft or not frame.GetRight or not frame.GetBottom or not frame.GetTop then
        return
    end

    local left = frame:GetLeft()
    local right = frame:GetRight()
    local bottom = frame:GetBottom()
    local top = frame:GetTop()
    if not left or not right or not bottom or not top then
        return
    end

    local parentWidth = UIParent and UIParent:GetWidth() or 0
    local parentHeight = UIParent and UIParent:GetHeight() or 0
    local offsetX = 0
    local offsetY = 0

    if left < WINDOW_SCREEN_MARGIN then
        offsetX = WINDOW_SCREEN_MARGIN - left
    elseif right > (parentWidth - WINDOW_SCREEN_MARGIN) then
        offsetX = (parentWidth - WINDOW_SCREEN_MARGIN) - right
    end

    if bottom < WINDOW_SCREEN_MARGIN then
        offsetY = WINDOW_SCREEN_MARGIN - bottom
    elseif top > (parentHeight - WINDOW_SCREEN_MARGIN) then
        offsetY = (parentHeight - WINDOW_SCREEN_MARGIN) - top
    end

    if offsetX == 0 and offsetY == 0 then
        return
    end

    frame:ClearAllPoints()
    frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left + offsetX, bottom + offsetY)
end

function module:ApplyWindowGeometry(frame)
    if not frame then
        return
    end

    local settings = self:GetWindowSettings()
    self:UpdateWindowResizeBounds(frame)
    local width, height
    if self:IsHomeTabActive() then
        width, height = ClampHomeWindowSize(self:GetActiveWindowWidth(settings), settings.height)
    else
        width, height = ClampWindowSize(self:GetActiveWindowWidth(settings), settings.height)
    end
    frame:SetSize(width, height)
    frame:ClearAllPoints()
    frame:SetPoint(settings.point or "CENTER", UIParent, settings.relativePoint or settings.point or "CENTER", settings.x or 0, settings.y or 0)
    self:EnsureWindowGeometryIsReachable(frame)
end

function module:GetNoteTabView(panel)
    return panel and panel.activeView
end

function module:GetNoteTabEditView(panel)
    return panel and panel.editView or nil
end

function module:GetNoteTabReadView(panel)
    return panel and panel.readView or nil
end

function module:GetNoteTabStoredTitle(tab)
    return NormalizeNoteTitle(tab and tab.noteData and tab.noteData.title or "Note")
end

function module:GetNoteTabWorkingValues(tab)
    local view = self:GetNoteTabEditView(tab and tab.panel)
    if not view then
        return self:GetNoteTabStoredTitle(tab), DEFAULT_NOTE_BODY
    end

    local titleText = view.titleInput and view.titleInput:GetText() or nil
    local bodyText = view.bodyInput and view.bodyInput:GetText() or nil
    return NormalizeNoteTitle(titleText), bodyText or DEFAULT_NOTE_BODY
end

function module:GetNoteTabDisplayTitle(tab)
    local title = self:GetNoteTabStoredTitle(tab)
    if tab and tab.dirty then
        title = self:GetNoteTabWorkingValues(tab)
        return title .. "*"
    end

    return title
end

function module:GetCursorItemId()
    local cursorType, cursorItemId, cursorItemLink = GetCursorInfo()
    if cursorType ~= "item" then
        return nil
    end

    return tonumber(cursorItemId) or ExtractItemIdFromItemLink(cursorItemLink)
end

function module:HandleNoteBodyItemDrop(tab, editBox)
    if not tab then
        return
    end

    local view = self:GetNoteTabEditView(tab.panel)
    editBox = editBox or (view and view.bodyInput or nil)
    if not editBox then
        return
    end

    local itemId = self:GetCursorItemId()
    if not itemId then
        return
    end

    local cursorPosition = editBox.GetCursorPosition and editBox:GetCursorPosition() or nil
    editBox:SetFocus()
    if cursorPosition and editBox.SetCursorPosition then
        editBox:SetCursorPosition(cursorPosition)
    end
    editBox:Insert(string.format("[%d]", itemId))
    self:HandleNoteTabContentChanged(tab)
    ClearCursor()
end

function module:RefreshNoteTabTitle(tab)
    if tab then
        self:SetTabTitle(tab, self:GetNoteTabDisplayTitle(tab))
    end
end

function module:RefreshNoteTabControls(tab)
    local panel = tab and tab.panel
    local editView = self:GetNoteTabEditView(panel)
    local readView = self:GetNoteTabReadView(panel)
    if not editView and not readView then
        return
    end

    local metaText = ""
    local isBuiltinNote = tab and tab.noteData and self:IsBuiltinNoteId(tab.noteData.noteId) or false
    if isBuiltinNote then
        metaText = "Built-in guide"
    elseif tab and tab.noteData and tab.noteData.updatedAt then
        metaText = FormatSmartTimestamp(tab.noteData.updatedAt, tab.noteData.createdAt)
    end

    if editView and editView.metaText then
        editView.metaText:SetText(metaText)
    end

    if readView and readView.metaText then
        readView.metaText:SetText(metaText)
    end

    local hasSavedNote = tab and tab.noteData and tab.noteData.noteId and true or false
    if editView and editView.deleteButton then
        editView.deleteButton:SetEnabled(hasSavedNote and not isBuiltinNote)
    end
    if readView and readView.deleteButton then
        readView.deleteButton:SetEnabled(hasSavedNote and not isBuiltinNote)
    end
    if readView and readView.exportButton then
        readView.exportButton:SetEnabled(hasSavedNote and not isBuiltinNote)
    end

    if editView and editView.modeButton then
        editView.modeButton:SetEnabled(not isBuiltinNote)
    end
    if readView and readView.modeButton then
        readView.modeButton:SetEnabled(not isBuiltinNote)
    end

    if editView and editView.saveButton then
        if tab and tab.dirty and not isBuiltinNote then
            editView.saveButton:Enable()
        else
            editView.saveButton:Disable()
        end
    end
end

function module:GetNoteTabMode(tab)
    if tab and tab.mode == "read" then
        return "read"
    end

    return "edit"
end

function module:IsNoteTabInEditMode(tab)
    return self:GetNoteTabMode(tab) == "edit"
end

function module:SetNoteTabDirty(tab, isDirty)
    if not tab then
        return
    end

    tab.dirty = isDirty and true or false
    self:RefreshNoteTabTitle(tab)
    self:RefreshNoteTabControls(tab)
end

function module:ConfirmDiscardIfDirty(tab, onConfirm)
    if type(onConfirm) ~= "function" then
        return
    end

    if not tab or not tab.dirty then
        onConfirm()
        return
    end

    StaticPopup_Show("SNAILSTUFF_NOTES_CONFIRM_DISCARD", nil, nil, {
        onConfirm = onConfirm,
    })
end

function module:HandleNoteTabContentChanged(tab)
    local panel = tab and tab.panel
    if not panel or panel.isLoadingView then
        return
    end

    self:SetNoteTabDirty(tab, true)
end

function module:GetNoteBodyTextHeight(bodyInput)
    if not bodyInput then
        return 0
    end

    local textHeight = bodyInput.GetTextHeight and bodyInput:GetTextHeight() or nil
    if tonumber(textHeight) and textHeight > 0 then
        return textHeight
    end

    local fontString = bodyInput.GetFontString and bodyInput:GetFontString() or nil
    if fontString and fontString.GetStringHeight then
        textHeight = fontString:GetStringHeight()
        if tonumber(textHeight) and textHeight > 0 then
            return textHeight
        end
    end

    return 0
end

function module:GetNoteBodyVisibleWidth(view, includeScrollbar)
    if not view or not view.bodyFrame then
        return NOTE_TAB_BODY_INITIAL_VISIBLE_WIDTH
    end

    local width = view.bodyScrollFrame and view.bodyScrollFrame:GetWidth() or 0
    if width and width > 1 then
        return width
    end

    width = (view.bodyFrame:GetWidth() or 0)
        - NOTE_TAB_BODY_NATIVE_LEFT_INSET
        - NOTE_TAB_BODY_NATIVE_RIGHT_INSET
    if includeScrollbar then
        width = width - NOTE_TAB_BODY_SCROLLBAR_WIDTH - NOTE_TAB_BODY_SCROLLBAR_GAP
    end

    return math.max(width, NOTE_TAB_BODY_INITIAL_VISIBLE_WIDTH)
end

function module:GetNoteBodyVisibleHeight(view)
    if not view or not view.bodyFrame then
        return NOTE_TAB_BODY_MIN_CONTENT_HEIGHT
    end

    local height = view.bodyScrollFrame and view.bodyScrollFrame:GetHeight() or 0
    if height and height > 1 then
        return height
    end

    height = (view.bodyFrame:GetHeight() or 0)
        - NOTE_TAB_BODY_NATIVE_TOP_INSET
        - NOTE_TAB_BODY_NATIVE_BOTTOM_INSET

    return math.max(height, NOTE_TAB_BODY_MIN_CONTENT_HEIGHT)
end

function module:GetNoteBodyContentHeight(view)
    if not view or not view.bodyInput then
        return NOTE_TAB_BODY_MIN_CONTENT_HEIGHT
    end

    local textHeight = self:GetNoteBodyTextHeight(view.bodyInput)
    local visibleHeight = self:GetNoteBodyVisibleHeight(view)
    local contentHeight = math.max(textHeight + (NOTE_TAB_FIELD_INNER_Y * 2), visibleHeight, NOTE_TAB_BODY_MIN_CONTENT_HEIGHT)
    return math.max(contentHeight, 1)
end

function module:GetNoteReadBodyTextHeight(view)
    if not view or not view.bodyLines then
        return 0
    end

    local textHeight = 0
    local previousLineType = nil
    for _, row in ipairs(view.bodyLines) do
        if row:IsShown() then
            textHeight = textHeight + math.max(row:GetHeight() or 0, 0)
            if previousLineType then
                textHeight = textHeight + self:GetReadViewLineSpacing(previousLineType, row.lineType)
            end
            previousLineType = row.lineType
        end
    end

    return math.max(tonumber(textHeight) or 0, 0)
end

function module:GetNoteReadBodyVisibleWidth(view, includeScrollbar)
    if not view or not view.bodyFrame then
        return NOTE_TAB_BODY_INITIAL_VISIBLE_WIDTH
    end

    local width = view.bodyScrollFrame and view.bodyScrollFrame:GetWidth() or 0
    if width and width > 1 then
        return width
    end

    width = (view.bodyFrame:GetWidth() or 0)
        - NOTE_TAB_BODY_NATIVE_LEFT_INSET
        - NOTE_TAB_BODY_NATIVE_RIGHT_INSET
    if includeScrollbar then
        width = width - NOTE_TAB_BODY_SCROLLBAR_WIDTH - NOTE_TAB_BODY_SCROLLBAR_GAP
    end

    return math.max(width, NOTE_TAB_BODY_INITIAL_VISIBLE_WIDTH)
end

function module:GetNoteReadBodyVisibleHeight(view)
    if not view or not view.bodyFrame then
        return NOTE_TAB_BODY_MIN_CONTENT_HEIGHT
    end

    local height = view.bodyScrollFrame and view.bodyScrollFrame:GetHeight() or 0
    if height and height > 1 then
        return height
    end

    height = (view.bodyFrame:GetHeight() or 0)
        - NOTE_TAB_BODY_NATIVE_TOP_INSET
        - NOTE_TAB_BODY_NATIVE_BOTTOM_INSET

    return math.max(height, NOTE_TAB_BODY_MIN_CONTENT_HEIGHT)
end

function module:GetNoteReadBodyContentHeight(view)
    if not view then
        return NOTE_TAB_BODY_MIN_CONTENT_HEIGHT
    end

    local textHeight = self:GetNoteReadBodyTextHeight(view)
    local visibleHeight = self:GetNoteReadBodyVisibleHeight(view)
    local contentHeight = math.max(textHeight, visibleHeight, NOTE_TAB_BODY_MIN_CONTENT_HEIGHT)
    return math.max(contentHeight, 1)
end

function module:GetOrCreateNoteReadLineRow(view, index)
    view.bodyLines = view.bodyLines or {}
    local row = view.bodyLines[index]
    if row then
        return row
    end

    row = CreateFrame("Frame", nil, view.bodyContent)
    row:SetHeight(1)

    row.bullet = row:CreateFontString(nil, "ARTWORK", "ChatFontNormal")
    row.bullet:SetPoint("TOPLEFT", NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
    row.bullet:SetJustifyH("LEFT")
    row.bullet:SetJustifyV("TOP")
    row.bullet:SetText("")
    row.bullet:Hide()

    row.text = row:CreateFontString(nil, "ARTWORK", "ChatFontNormal")
    row.text:SetPoint("TOPLEFT", NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
    row.text:SetPoint("TOPRIGHT", -NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
    row.text:SetJustifyH("LEFT")
    row.text:SetJustifyV("TOP")
    row.text:SetWordWrap(true)
    if row.text.SetNonSpaceWrap then
        row.text:SetNonSpaceWrap(true)
    end
    row.text:SetText("")

    row.separator = row:CreateTexture(nil, "ARTWORK")
    row.separator:SetTexture("Interface\\Buttons\\WHITE8x8")
    row.separator:SetVertexColor(unpack(READ_SEPARATOR_COLOR))
    row.separator:Hide()

    row.codeBackground = row:CreateTexture(nil, "BACKGROUND")
    row.codeBackground:SetAllPoints()
    row.codeBackground:SetTexture("Interface\\Buttons\\WHITE8x8")
    row.codeBackground:SetVertexColor(unpack(READ_CODE_BACKGROUND_COLOR))
    row.codeBackground:Hide()

    row.atlasTexture = row:CreateTexture(nil, "ARTWORK")
    row.atlasTexture:Hide()

    row.measure = row:CreateFontString(nil, "ARTWORK", "ChatFontNormal")
    row.measure:Hide()

    row.hoverRegions = {}

    view.bodyLines[index] = row
    return row
end

function module:GetReadViewLineSpacing(previousLineType, currentLineType)
    if previousLineType == "h1" or previousLineType == "h2" or previousLineType == "h3" then
        return READ_HEADER_VERTICAL_SPACING
    end

    if previousLineType == "separator" or currentLineType == "separator" then
        return 6
    end

    if previousLineType == "bullet" and currentLineType ~= "bullet" then
        return READ_POST_BULLET_BLOCK_SPACING
    end

    if (previousLineType == "plain" or previousLineType == "bold" or previousLineType == "italic")
        and (currentLineType == "plain" or currentLineType == "bold" or currentLineType == "italic")
    then
        return READ_LINE_VERTICAL_SPACING
    end

    return 0
end

function module:ResolveReadViewItemTokenText(itemId, fallbackText)
    local numericItemId = tonumber(itemId)
    local fallback = tostring(fallbackText or "")
    if not numericItemId then
        return fallback, false, nil
    end

    local itemName, itemLink = GetItemInfo(numericItemId)
    if itemName and itemLink and itemLink ~= "" then
        return itemLink, true, itemLink
    end

    if C_Item and C_Item.RequestLoadItemDataByID then
        C_Item.RequestLoadItemDataByID(numericItemId)
    end

    return fallback, false, nil
end

function module:ShouldListenForReadItemInfoUpdates()
    if not self.runtime or not self.runtime.noteSlots then
        return false
    end

    for _, tab in ipairs(self.runtime.noteSlots) do
        if tab and tab.assigned and not self:IsNoteTabInEditMode(tab) and tab.hasPendingReadItemInfo then
            return true
        end
    end

    return false
end

function module:UpdateReadItemInfoEventRegistration()
    local shouldListen = self:ShouldListenForReadItemInfoUpdates()
    if shouldListen then
        if not self.runtime.isListeningForReadItemInfo then
            self:RegisterEvent("GET_ITEM_INFO_RECEIVED")
            self:RegisterEvent("ITEM_DATA_LOAD_RESULT")
            self.runtime.isListeningForReadItemInfo = true
        end
    elseif self.runtime and self.runtime.isListeningForReadItemInfo then
        self:UnregisterEvent("GET_ITEM_INFO_RECEIVED")
        self:UnregisterEvent("ITEM_DATA_LOAD_RESULT")
        self.runtime.isListeningForReadItemInfo = false
    end
end

function module:TrackPendingReadItemId(pendingItemIds, itemId)
    local numericItemId = tonumber(itemId)
    if not pendingItemIds or not numericItemId then
        return
    end

    pendingItemIds[numericItemId] = true
end

function module:GetReadViewDefaultFont()
    local _, _, fontFlags = ChatFontNormal:GetFont()
    return FONT_REGULAR or STANDARD_TEXT_FONT, fontFlags or ""
end

function module:GetReadViewFontPath(lineType, fallbackFontPath)
    if lineType == "h1italic" or lineType == "h2italic" or lineType == "h3italic" then
        return FONT_BOLDITALIC or FONT_BOLD or FONT_REGULAR or fallbackFontPath
    end

    if lineType == "h1" or lineType == "h2" or lineType == "h3" then
        return FONT_BOLD or FONT_REGULAR or fallbackFontPath
    end

    if lineType == "bold" then
        return FONT_BOLD or FONT_REGULAR or fallbackFontPath
    end

    if lineType == "bolditalic" then
        return FONT_BOLDITALIC or FONT_BOLD or FONT_REGULAR or fallbackFontPath
    end

    if lineType == "italic" then
        return FONT_ITALIC or FONT_REGULAR or fallbackFontPath
    end

    return FONT_REGULAR or fallbackFontPath
end

function module:ApplyReadViewFont(target, preferredFontPath, fallbackFontPath, fontSize, fontFlags)
    if not target or not target.SetFont then
        return
    end

    local didApplyPreferred = preferredFontPath and target:SetFont(preferredFontPath, fontSize, fontFlags)
    if didApplyPreferred then
        return
    end

    target:SetFont(fallbackFontPath or STANDARD_TEXT_FONT, fontSize, fontFlags)
end

function module:GetReadViewRowAvailableWidth(row)
    if not row then
        return 1
    end

    local width = row:GetWidth() or 0
    if width <= 1 and row.GetParent then
        local parent = row:GetParent()
        width = parent and parent:GetWidth() or 0
    end

    return math.max(width - (NOTE_TAB_FIELD_INNER_X * 2), 1)
end

function module:TryApplyReadViewAtlas(row, atlasData)
    if not row or not row.atlasTexture or not atlasData or not atlasData.atlasName or atlasData.atlasName == "" then
        return false
    end

    if C_Texture and C_Texture.GetAtlasElementID and not C_Texture.GetAtlasElementID(atlasData.atlasName) then
        return false
    end

    row.atlasTexture:ClearAllPoints()

    local didSetAtlas
    local intendedWidth
    local intendedHeight
    if atlasData.width and atlasData.height then
        didSetAtlas = pcall(row.atlasTexture.SetAtlas, row.atlasTexture, atlasData.atlasName)
        if not didSetAtlas then
            row.atlasTexture:SetTexture(nil)
            row.atlasTexture:Hide()
            return false
        end
        intendedWidth = atlasData.width
        intendedHeight = atlasData.height
    else
        didSetAtlas = pcall(row.atlasTexture.SetAtlas, row.atlasTexture, atlasData.atlasName, true)
        if not didSetAtlas then
            row.atlasTexture:SetTexture(nil)
            row.atlasTexture:Hide()
            return false
        end

        intendedWidth, intendedHeight = row.atlasTexture:GetSize()
    end

    if not intendedWidth or intendedWidth <= 0 or not intendedHeight or intendedHeight <= 0 then
        row.atlasTexture:SetTexture(nil)
        row.atlasTexture:Hide()
        return false
    end

    local maxWidth = self:GetReadViewRowAvailableWidth(row)
    local scale = 1
    if intendedWidth > maxWidth then
        scale = maxWidth / intendedWidth
    end

    local atlasWidth = math.max(math.floor((intendedWidth * scale) + 0.5), 1)
    local atlasHeight = math.max(math.floor((intendedHeight * scale) + 0.5), 1)
    row.atlasTexture:SetSize(atlasWidth, atlasHeight)

    if row.isCentered then
        row.atlasTexture:SetPoint("TOP", row, "TOP", 0, -NOTE_TAB_FIELD_INNER_Y)
    else
        row.atlasTexture:SetPoint("TOPLEFT", row, "TOPLEFT", NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
    end

    row.atlasWidth = atlasWidth
    row.atlasHeight = atlasHeight
    row.atlasData = atlasData
    row.atlasTexture:Show()
    return true
end

function module:GetOrCreateReadItemHoverRegion(row, index)
    row.hoverRegions = row.hoverRegions or {}
    local region = row.hoverRegions[index]
    if region then
        return region
    end

    region = CreateFrame("Button", nil, row)
    region:SetFrameStrata(row:GetFrameStrata())
    region:SetFrameLevel((row:GetFrameLevel() or 1) + 10)
    region:RegisterForClicks("AnyUp")
    region:EnableMouse(true)
    region:Hide()
    region:SetScript("OnEnter", function(selfRegion)
        local segmentData = selfRegion.segmentData
        if not segmentData then
            return
        end

        GameTooltip:SetOwner(selfRegion, "ANCHOR_RIGHT")
        if segmentData.isResolved and segmentData.itemLink then
            GameTooltip:SetHyperlink(segmentData.itemLink)
        else
            GameTooltip:SetText(segmentData.text or "", 1, 0.82, 0)
            GameTooltip:AddLine("Item invalid or not cached", 0.92, 0.88, 0.80, true)
        end
        GameTooltip:Show()
    end)
    region:SetScript("OnLeave", function()
        GameTooltip:Hide()
    end)
    region:SetScript("OnClick", function(selfRegion, button)
        local segmentData = selfRegion.segmentData
        local itemLink = segmentData and segmentData.itemLink or nil
        if not segmentData or not segmentData.isResolved or not itemLink or itemLink == "" then
            return
        end

        if HandleModifiedItemClick and HandleModifiedItemClick(itemLink) then
            return
        end

        if SetItemRef then
            SetItemRef(itemLink, itemLink, button or "LeftButton", selfRegion)
        end
    end)

    row.hoverRegions[index] = region
    return region
end

function module:HideReadItemHoverRegions(row)
    if not row or not row.hoverRegions then
        return
    end

    for _, region in ipairs(row.hoverRegions) do
        region.segmentData = nil
        region:Hide()
    end
end

function module:RefreshReadItemHoverRegions(row, resolvedFontPath, fallbackFontPath, fontSize, fontFlags)
    if not row or not row.text or not row.measure then
        return
    end

    self:HideReadItemHoverRegions(row)

    local segments = row.inlineSegments
    if not segments or #segments == 0 then
        return
    end

    self:ApplyReadViewFont(row.measure, resolvedFontPath, fallbackFontPath, fontSize, fontFlags)
    row.measure:SetSpacing(row.text.GetSpacing and row.text:GetSpacing() or 0)

    local lineHeight = select(2, row.measure:GetFont())
    local textHeight = row.text:GetStringHeight() or 0
    if not lineHeight or lineHeight <= 0 or textHeight > (lineHeight * 1.5) then
        return
    end

    local prefixText = ""
    local hoverIndex = 0
    for _, segmentData in ipairs(segments) do
        local displayText = segmentData.displayText or segmentData.text or ""
        if segmentData.kind == "itemToken" and displayText ~= "" then
            row.measure:SetText(prefixText)
            local prefixWidth = row.measure:GetStringWidth() or 0

            row.measure:SetText(displayText)
            local segmentWidth = row.measure:GetStringWidth() or 0

            if segmentWidth > 0 then
                hoverIndex = hoverIndex + 1
                local region = self:GetOrCreateReadItemHoverRegion(row, hoverIndex)
                region.segmentData = segmentData
                region:ClearAllPoints()
                region:SetPoint("TOPLEFT", row.text, "TOPLEFT", prefixWidth, 0)
                region:SetSize(segmentWidth, math.max(textHeight, lineHeight))
                region:Show()
            end
        end

        prefixText = prefixText .. displayText
    end
end

function module:ApplyReadViewLineStyle(row, lineType, displayText, pendingItemIds)
    if not row or not row.text or not row.bullet then
        return false
    end

    local fallbackFontPath, fontFlags = self:GetReadViewDefaultFont()
    local resolvedFontPath = self:GetReadViewFontPath(lineType, fallbackFontPath)
    local fontSize = READ_LINE_FONT_SIZE
    local isCenteredBullet = lineType == "bullet" and row.isCentered

    row.bullet:Hide()
    row.bullet:SetText("")
    if row.separator then
        row.separator:Hide()
    end
    if row.codeBackground then
        row.codeBackground:Hide()
    end
    if row.atlasTexture then
        row.atlasTexture:Hide()
    end
    row.renderedLineType = nil
    row.atlasWidth = nil
    row.atlasHeight = nil
    row.atlasData = nil

    if lineType == "h1" then
        fontSize = READ_HEADER1_FONT_SIZE
    elseif lineType == "h2" then
        fontSize = READ_HEADER2_FONT_SIZE
    elseif lineType == "h3" then
        fontSize = READ_HEADER3_FONT_SIZE
    elseif lineType == "bold" then
        fontSize = READ_LINE_FONT_SIZE
    elseif lineType == "bolditalic" then
        fontSize = READ_LINE_FONT_SIZE
    elseif lineType == "italic" then
        fontSize = READ_LINE_FONT_SIZE
    elseif lineType == "bullet" then
        if not isCenteredBullet then
            self:ApplyReadViewFont(row.bullet, fallbackFontPath, fallbackFontPath, READ_LINE_FONT_SIZE, fontFlags)
            row.bullet:SetText("•")
            row.bullet:Show()
        end
    elseif lineType == "separator" then
        fontSize = READ_LINE_FONT_SIZE
    elseif lineType == "blank" then
        fontSize = READ_LINE_FONT_SIZE
    end

    row.text:ClearAllPoints()
    if lineType == "bullet" and not isCenteredBullet then
        row.text:SetPoint("TOPLEFT", row.bullet, "TOPRIGHT", 6, 0)
        row.text:SetPoint("TOPRIGHT", row, "TOPRIGHT", -NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
        row.text:SetJustifyH("LEFT")
    else
        row.text:SetPoint("TOPLEFT", row, "TOPLEFT", NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
        row.text:SetPoint("TOPRIGHT", row, "TOPRIGHT", -NOTE_TAB_FIELD_INNER_X, -NOTE_TAB_FIELD_INNER_Y)
        row.text:SetJustifyH(row.isCentered and "CENTER" or "LEFT")
    end
    self:ApplyReadViewFont(row.text, resolvedFontPath, fallbackFontPath, fontSize, fontFlags)
    row.text:SetTextColor(1, 1, 1)
    row.text:SetShadowOffset(0, 0)
    row.text:SetShadowColor(0, 0, 0, 0)

    if lineType == "h1" or lineType == "h2" then
        row.text:SetShadowOffset(3, -3)
        row.text:SetShadowColor(0, 0, 0, 0.60)
    end

    if lineType == "separator" then
        row.renderedLineType = "separator"
        row.text:SetText("")
        row.inlineSegments = nil
        self:HideReadItemHoverRegions(row)
        if row.separator then
            row.separator:ClearAllPoints()
            row.separator:SetPoint("LEFT", row, "LEFT", NOTE_TAB_FIELD_INNER_X + READ_SEPARATOR_SIDE_INSET, 0)
            row.separator:SetPoint("RIGHT", row, "RIGHT", -(NOTE_TAB_FIELD_INNER_X + READ_SEPARATOR_SIDE_INSET), 0)
            row.separator:SetHeight(READ_SEPARATOR_THICKNESS)
            row.separator:Show()
        end
        return false
    end

    if lineType == "code" then
        row.renderedLineType = "code"
        row.inlineSegments = nil
        self:HideReadItemHoverRegions(row)
        if row.codeBackground then
            row.codeBackground:Show()
        end
        row.text:SetJustifyH("LEFT")
        row.text:SetText(tostring(displayText or ""))
        return false
    end

    if lineType == "atlas" then
        row.text:SetText("")
        row.inlineSegments = nil
        self:HideReadItemHoverRegions(row)
        if self:TryApplyReadViewAtlas(row, displayText) then
            row.renderedLineType = "atlas"
            return false
        end

        lineType = "plain"
        displayText = displayText and displayText.rawText or ""
    end

    local segments = ParseReadViewInlineSegments(displayText or "")
    if isCenteredBullet then
        table.insert(segments, 1, {
            kind = "text",
            text = "• ",
            displayText = "• ",
        })
    end
    local formattedSegments = {}
    local hasUnresolvedItemTokens = false

    for _, segmentData in ipairs(segments) do
        if segmentData.kind == "itemToken" then
            local resolvedText, isResolved, itemLink = self:ResolveReadViewItemTokenText(segmentData.itemId, segmentData.text)
            segmentData.displayText = resolvedText
            segmentData.isResolved = isResolved
            segmentData.itemLink = itemLink
            if isResolved then
                formattedSegments[#formattedSegments + 1] = resolvedText
            else
                hasUnresolvedItemTokens = true
                self:TrackPendingReadItemId(pendingItemIds, segmentData.itemId)
                formattedSegments[#formattedSegments + 1] = string.format(
                    "|cff%02x%02x%02x%s|r",
                    math.floor((READ_UNRESOLVED_ITEM_TOKEN_COLOR[1] or 1) * 255),
                    math.floor((READ_UNRESOLVED_ITEM_TOKEN_COLOR[2] or 1) * 255),
                    math.floor((READ_UNRESOLVED_ITEM_TOKEN_COLOR[3] or 1) * 255),
                    resolvedText or ""
                )
            end
        else
            segmentData.displayText = segmentData.text or ""
            formattedSegments[#formattedSegments + 1] = segmentData.text or ""
        end
    end

    row.inlineSegments = segments
    row.renderedLineType = lineType
    row.text:SetText(table.concat(formattedSegments))
    self:RefreshReadItemHoverRegions(row, resolvedFontPath, fallbackFontPath, fontSize, fontFlags)
    return hasUnresolvedItemTokens
end

function module:GetReadViewLineRowHeight(row)
    if not row then
        return 1
    end

    if row.lineType == "blank" then
        return math.max(READ_BLANK_LINE_HEIGHT, 1)
    end

    if row.lineType == "separator" then
        return math.max(READ_SEPARATOR_ROW_HEIGHT, 1)
    end

    if row.lineType == "code" then
        return math.max((row.text and row.text:GetStringHeight() or 0) + (NOTE_TAB_FIELD_INNER_Y * 2), READ_LINE_FONT_SIZE + (NOTE_TAB_FIELD_INNER_Y * 2), 1)
    end

    if row.lineType == "atlas" and row.atlasHeight then
        return math.max(row.atlasHeight + (NOTE_TAB_FIELD_INNER_Y * 2), 1)
    end

    return math.max((row.text and row.text:GetStringHeight() or 0) + (NOTE_TAB_FIELD_INNER_Y * 2), 1)
end

function module:RefreshNoteReadLineRows(view, bodyText)
    if not view or not view.bodyContent then
        return false
    end

    local lines = SplitNoteBodyIntoLines(bodyText)
    local renderedLineCount = 0
    local previousRow = nil
    local previousLineType = nil
    local previousIndentOffset = 0
    local isCenteredBlock = false
    local isCodeBlock = false
    local hasUnresolvedItemTokens = false
    local pendingItemIds = {}
    for _, lineText in ipairs(lines) do
        if isCodeBlock then
            if IsReadViewCodeBlockEnd(lineText) then
                isCodeBlock = false
            else
                renderedLineCount = renderedLineCount + 1
                local row = self:GetOrCreateNoteReadLineRow(view, renderedLineCount)
                local lineType = "code"
                local displayText = lineText
                local indentOffset = 0
                row.isCentered = false
                row:ClearAllPoints()
                row:SetPoint("LEFT", view.bodyContent, "LEFT", indentOffset, 0)
                row:SetPoint("RIGHT", view.bodyContent, "RIGHT", 0, 0)

                local rowHasUnresolvedItemTokens = self:ApplyReadViewLineStyle(row, lineType, displayText, pendingItemIds)
                row.lineType = row.renderedLineType or lineType
                if previousRow then
                    row:SetPoint("TOPLEFT", previousRow, "BOTTOMLEFT", indentOffset - previousIndentOffset, -self:GetReadViewLineSpacing(previousLineType, row.lineType))
                else
                    row:SetPoint("TOPLEFT", view.bodyContent, "TOPLEFT", indentOffset, 0)
                end
                row:SetHeight(self:GetReadViewLineRowHeight(row))
                row:Show()
                previousRow = row
                previousLineType = row.lineType
                previousIndentOffset = indentOffset
                hasUnresolvedItemTokens = hasUnresolvedItemTokens or rowHasUnresolvedItemTokens
            end
        elseif IsReadViewCodeBlockStart(lineText) then
            isCodeBlock = true
        elseif IsReadViewCenteredBlockStart(lineText) then
            isCenteredBlock = true
        elseif IsReadViewCenteredBlockEnd(lineText) then
            isCenteredBlock = false
        else
            renderedLineCount = renderedLineCount + 1
            local row = self:GetOrCreateNoteReadLineRow(view, renderedLineCount)
            local lineType, displayText = ClassifyReadViewLine(lineText)
            local isCenteredRow = isCenteredBlock
            local indentOffset = (lineType == "bullet" and not isCenteredRow) and READ_BULLET_INDENT or 0
            row.isCentered = isCenteredRow
            row:ClearAllPoints()
            row:SetPoint("LEFT", view.bodyContent, "LEFT", indentOffset, 0)
            row:SetPoint("RIGHT", view.bodyContent, "RIGHT", 0, 0)

            local rowHasUnresolvedItemTokens = self:ApplyReadViewLineStyle(row, lineType, displayText, pendingItemIds)
            row.lineType = row.renderedLineType or lineType
            if previousRow then
                row:SetPoint("TOPLEFT", previousRow, "BOTTOMLEFT", indentOffset - previousIndentOffset, -self:GetReadViewLineSpacing(previousLineType, row.lineType))
            else
                row:SetPoint("TOPLEFT", view.bodyContent, "TOPLEFT", indentOffset, 0)
            end
            row:SetHeight(self:GetReadViewLineRowHeight(row))
            row:Show()
            previousRow = row
            previousLineType = row.lineType
            previousIndentOffset = indentOffset
            hasUnresolvedItemTokens = hasUnresolvedItemTokens or rowHasUnresolvedItemTokens
        end
    end

    for index = renderedLineCount + 1, #(view.bodyLines or {}) do
        local row = view.bodyLines[index]
        if row then
            self:HideReadItemHoverRegions(row)
            row:Hide()
            row.lineType = nil
            row.renderedLineType = nil
            row.inlineSegments = nil
            row.atlasData = nil
        end
    end

    view.hasPendingReadItemInfo = hasUnresolvedItemTokens
    view.pendingReadItemIds = pendingItemIds
    return hasUnresolvedItemTokens
end

function module:RefreshNoteReadLineRowHeights(view)
    if not view or not view.bodyLines then
        return
    end

    for _, row in ipairs(view.bodyLines) do
        if row:IsShown() and row.text then
            if row.lineType == "atlas" and row.atlasData then
                self:TryApplyReadViewAtlas(row, row.atlasData)
            end
            row:SetHeight(self:GetReadViewLineRowHeight(row))
        end
    end
end

function module:UpdateNoteBodyEditLayout(tab)
    local view = self:GetNoteTabEditView(tab and tab.panel)
    if not view or not view.bodyFrame or not view.bodyInput or not view.bodyScrollFrame then
        return
    end

    local scrollBar = view.bodyScrollBar
    local reserveScrollbar = scrollBar and scrollBar:IsShown() or false
    local rightInset = NOTE_TAB_BODY_NATIVE_RIGHT_INSET + (reserveScrollbar and (NOTE_TAB_BODY_SCROLLBAR_WIDTH + NOTE_TAB_BODY_SCROLLBAR_GAP) or 0)

    view.bodyScrollFrame:ClearAllPoints()
    view.bodyScrollFrame:SetPoint("TOPLEFT", view.bodyFrame, "TOPLEFT", NOTE_TAB_BODY_NATIVE_LEFT_INSET, -NOTE_TAB_BODY_NATIVE_TOP_INSET)
    view.bodyScrollFrame:SetPoint("BOTTOMRIGHT", view.bodyFrame, "BOTTOMRIGHT", -rightInset, NOTE_TAB_BODY_NATIVE_BOTTOM_INSET)

    if scrollBar then
        scrollBar:ClearAllPoints()
        scrollBar:SetWidth(NOTE_TAB_BODY_SCROLLBAR_WIDTH)
        scrollBar:SetPoint("TOPLEFT", view.bodyFrame, "TOPRIGHT", NOTE_TAB_BODY_SCROLLBAR_LEFT_INSET + NOTE_TAB_BODY_SCROLLBAR_X_OFFSET, -(NOTE_TAB_BODY_NATIVE_TOP_INSET + NOTE_TAB_BODY_SCROLLBAR_TOP_INSET))
        scrollBar:SetPoint("BOTTOMRIGHT", view.bodyFrame, "BOTTOMRIGHT", -(NOTE_TAB_BODY_SCROLLBAR_RIGHT_INSET - NOTE_TAB_BODY_SCROLLBAR_X_OFFSET), NOTE_TAB_BODY_NATIVE_BOTTOM_INSET + NOTE_TAB_BODY_SCROLLBAR_BOTTOM_INSET)
    end

    view.bodyInput:SetWidth(self:GetNoteBodyVisibleWidth(view, reserveScrollbar))
    view.bodyInput:SetHeight(self:GetNoteBodyContentHeight(view))
end

function module:UpdateNoteBodyReadLayout(tab)
    local view = self:GetNoteTabReadView(tab and tab.panel)
    if not view or not view.bodyFrame or not view.bodyScrollFrame or not view.bodyContent then
        return
    end

    local scrollBar = view.bodyScrollBar
    local reserveScrollbar = scrollBar and scrollBar:IsShown() or false
    local rightInset = NOTE_TAB_BODY_NATIVE_RIGHT_INSET + (reserveScrollbar and (NOTE_TAB_BODY_SCROLLBAR_WIDTH + NOTE_TAB_BODY_SCROLLBAR_GAP) or 0)

    view.bodyScrollFrame:ClearAllPoints()
    view.bodyScrollFrame:SetPoint("TOPLEFT", view.bodyFrame, "TOPLEFT", NOTE_TAB_BODY_NATIVE_LEFT_INSET, -NOTE_TAB_BODY_NATIVE_TOP_INSET)
    view.bodyScrollFrame:SetPoint("BOTTOMRIGHT", view.bodyFrame, "BOTTOMRIGHT", -rightInset, NOTE_TAB_BODY_NATIVE_BOTTOM_INSET)

    if scrollBar then
        scrollBar:ClearAllPoints()
        scrollBar:SetWidth(NOTE_TAB_BODY_SCROLLBAR_WIDTH)
        scrollBar:SetPoint("TOPLEFT", view.bodyFrame, "TOPRIGHT", NOTE_TAB_BODY_SCROLLBAR_LEFT_INSET + NOTE_TAB_BODY_SCROLLBAR_X_OFFSET, -(NOTE_TAB_BODY_NATIVE_TOP_INSET + NOTE_TAB_BODY_SCROLLBAR_TOP_INSET))
        scrollBar:SetPoint("BOTTOMRIGHT", view.bodyFrame, "BOTTOMRIGHT", -(NOTE_TAB_BODY_SCROLLBAR_RIGHT_INSET - NOTE_TAB_BODY_SCROLLBAR_X_OFFSET), NOTE_TAB_BODY_NATIVE_BOTTOM_INSET + NOTE_TAB_BODY_SCROLLBAR_BOTTOM_INSET)
    end

    view.bodyContent:SetWidth(self:GetNoteReadBodyVisibleWidth(view, reserveScrollbar))
    self:RefreshNoteReadLineRowHeights(view)
    view.bodyContent:SetHeight(self:GetNoteReadBodyContentHeight(view))
end

function module:RefreshNoteReadView(tab)
    local readView = self:GetNoteTabReadView(tab and tab.panel)
    if not readView then
        return
    end

    local title = self:GetNoteTabStoredTitle(tab)
    local body = tab and tab.noteData and tab.noteData.body or DEFAULT_NOTE_BODY
    readView.titleText:SetText(title)
    tab.hasPendingReadItemInfo = self:RefreshNoteReadLineRows(readView, body or DEFAULT_NOTE_BODY)
    tab.pendingReadItemIds = readView.pendingReadItemIds
    self:UpdateNoteBodyReadLayout(tab)
    self:UpdateReadItemInfoEventRegistration()
end

function module:QueueDeferredNoteReadViewRefresh(tab)
    if not tab or tab.pendingDeferredReadRefresh then
        return
    end

    tab.pendingDeferredReadRefresh = true
    C_Timer.After(0, function()
        tab.pendingDeferredReadRefresh = nil

        if not tab.panel or module:IsNoteTabInEditMode(tab) then
            return
        end

        local readView = module:GetNoteTabReadView(tab.panel)
        if not readView or not readView:IsShown() then
            return
        end

        module:RefreshNoteReadView(tab)
    end)
end

function module:ApplyTabMode(tab)
    if not tab or not tab.panel then
        return
    end

    local panel = tab.panel
    local editView = self:GetNoteTabEditView(panel)
    local readView = self:GetNoteTabReadView(panel)
    local isEditMode = self:IsNoteTabInEditMode(tab)

    if editView then
        editView:SetShown(isEditMode)
        if editView.modeButton then
            editView.modeButton:SetText(isEditMode and "Cancel" or "Edit")
        end
        if editView.saveButton then
            editView.saveButton:SetShown(isEditMode)
        end
    end

    if readView then
        readView:SetShown(not isEditMode)
        if readView.modeButton then
            readView.modeButton:SetText(isEditMode and "Cancel" or "Edit")
        end
    end

    panel.activeView = isEditMode and editView or readView

    if isEditMode then
        self:UpdateNoteBodyEditLayout(tab)
    else
        self:RefreshNoteReadView(tab)
    end
end

function module:SetNoteTabMode(tab, mode)
    if not tab then
        return
    end

    if mode == "read" then
        tab.mode = "read"
    else
        tab.mode = "edit"
    end

    self:ApplyTabMode(tab)
    self:RefreshNoteTabControls(tab)
    self:UpdateReadItemInfoEventRegistration()
end

function module:RestoreSavedNoteToTab(tab)
    if not tab or not tab.noteData or not tab.noteData.noteId then
        return
    end

    local note = self:GetNoteById(tab.noteData.noteId)
    if note then
        self:LoadNoteIntoTab(tab, note)
    end
end

function module:HandleNoteModeButtonClicked(tab)
    if not tab then
        return
    end

    if tab.noteData and self:IsBuiltinNoteId(tab.noteData.noteId) then
        return
    end

    if self:IsNoteTabInEditMode(tab) then
        if tab.noteData and tab.noteData.noteId then
            self:ConfirmDiscardIfDirty(tab, function()
                module:RestoreSavedNoteToTab(tab)
                module:SetNoteTabMode(tab, "read")
            end)
        else
            self:ConfirmDiscardIfDirty(tab, function()
                module:CloseTab(tab)
            end)
        end
        return
    end

    self:SetNoteTabMode(tab, "edit")
end

function module:LoadNoteIntoTab(tab, note)
    local panel = tab and tab.panel
    local view = self:GetNoteTabEditView(panel)
    if not tab or not panel or not view then
        return
    end

    local title = NormalizeNoteTitle(note and note.title or tab.noteData and tab.noteData.title or "Note")
    local body = note and note.body or tab.noteData and tab.noteData.body or DEFAULT_NOTE_BODY

    tab.noteData = tab.noteData or {}
    tab.noteData.noteId = note and note.id or tab.noteData.noteId
    tab.noteData.title = title
    tab.noteData.body = body
    tab.noteData.createdAt = note and note.createdAt or tab.noteData.createdAt
    tab.noteData.updatedAt = note and note.updatedAt or tab.noteData.updatedAt

    panel.isLoadingView = true
    view.titleInput:SetText(title)
    view.bodyInput:SetText(body)
    view.bodyInput:SetCursorPosition(0)
    panel.isLoadingView = false

    self:UpdateNoteBodyEditLayout(tab)
    self:SetNoteTabDirty(tab, false)
    self:RefreshNoteReadView(tab)
end

function module:RefreshNotePanel(tab)
    if not tab or not tab.panel then
        return
    end

    local note = tab.noteData and tab.noteData.noteId and self:GetNoteById(tab.noteData.noteId) or nil
    if note then
        self:LoadNoteIntoTab(tab, note)
        self:ApplyTabMode(tab)
        return
    end

    self:RefreshNoteTabTitle(tab)
    self:RefreshNoteTabControls(tab)
    self:RefreshNoteReadView(tab)
    self:ApplyTabMode(tab)
end

function module:RefreshSavedNoteReferences(tab)
    if not tab then
        return
    end

    self:RefreshNoteTabTitle(tab)
    self:RefreshNoteTabControls(tab)
    self:RefreshHomeList()
    self:RefreshRowActionMenu()
end

function module:SaveNoteTab(tab)
    if not tab or not tab.noteData then
        return false
    end

    if self:IsBuiltinNoteId(tab.noteData.noteId) then
        return false
    end

    local view = self:GetNoteTabEditView(tab.panel)
    local rawTitle = view and view.titleInput and view.titleInput:GetText() or tab.noteData.title or ""
    local trimmedTitle = TrimNoteTitle(rawTitle)
    if trimmedTitle == "" then
        StaticPopup_Show("SNAILSTUFF_NOTES_TITLE_REQUIRED", nil, nil, {
            tab = tab,
        })
        return false
    end

    local title, body = self:GetNoteTabWorkingValues(tab)
    local now = time()
    local note = nil
    local isNewNote = not tab.noteData.noteId

    if tab.noteData.noteId then
        note = self:GetNoteById(tab.noteData.noteId)
        if not note then
            return false
        end
    else
        note = {
            id = self:BuildNextNoteId(),
            createdAt = now,
        }
        self:GetNotesTable()[note.id] = note
        tab.noteData.noteId = note.id
    end

    if isNewNote then
        title = self:GetUniqueNoteTitle(title, note.id)
    end

    note.title = title
    note.body = body
    note.updatedAt = now
    note.createdAt = note.createdAt or now

    tab.noteData.title = title
    tab.noteData.body = body
    tab.noteData.createdAt = note.createdAt
    tab.noteData.updatedAt = now

    if view and view.titleInput:GetText() ~= title then
        tab.panel.isLoadingView = true
        view.titleInput:SetText(title)
        tab.panel.isLoadingView = false
    end

    self:SetSelectedNote(note.id)
    self:SetNoteTabDirty(tab, false)
    self:RefreshNoteReadView(tab)
    self:SetNoteTabMode(tab, "read")
    self:RefreshSavedNoteReferences(tab)
    return true
end

function module:SaveNoteTabIfDirty(tab)
    if tab and tab.dirty then
        return self:SaveNoteTab(tab)
    end

    return true
end

function module:CreateNoteEditView(parent)
    local view = CreateFrame("Frame", nil, parent)
    view:SetAllPoints()

    view.topRow = CreateFrame("Frame", nil, view)
    view.topRow:SetHeight(NOTE_TAB_TOP_ROW_HEIGHT)
    view.topRow:SetPoint("TOPLEFT", NOTE_TAB_SIDE_INSET, -NOTE_TAB_TOP_ROW_TOP_OFFSET)
    view.topRow:SetPoint("TOPRIGHT", -NOTE_TAB_SIDE_INSET, -NOTE_TAB_TOP_ROW_TOP_OFFSET)

    view.saveButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.saveButton:SetSize(NOTE_TAB_SAVE_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.saveButton:SetText("Save")

    view.modeButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.modeButton:SetSize(NOTE_TAB_MODE_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.modeButton:SetText("Cancel")

    view.deleteButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.deleteButton:SetSize(NOTE_TAB_DELETE_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.deleteButton:SetText("Delete")

    view.closeButton = CreateFrame("Button", nil, view.topRow, "UIPanelCloseButton")
    view.closeButton:SetSize(NOTE_TAB_TOP_CLOSE_BUTTON_SIZE, NOTE_TAB_TOP_CLOSE_BUTTON_SIZE)
    view.closeButton:ClearAllPoints()
    view.closeButton:SetPoint("RIGHT", view.topRow, "RIGHT", -NOTE_TAB_TOP_ROW_CLOSE_BUTTON_RIGHT_INSET, 0)
    view.closeButton:SetHitRectInsets(
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_LEFT,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_RIGHT,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_TOP,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_BOTTOM
    )

    view.saveButton:ClearAllPoints()
    view.saveButton:SetPoint("RIGHT", view.closeButton, "LEFT", -NOTE_TAB_TOP_CLOSE_BUTTON_SPACING, 0)

    view.modeButton:ClearAllPoints()
    view.modeButton:SetPoint("RIGHT", view.saveButton, "LEFT", -4, 0)

    view.deleteButton:ClearAllPoints()
    view.deleteButton:SetPoint("RIGHT", view.modeButton, "LEFT", -4, 0)

    view.titleInput = CreateFrame("EditBox", nil, view.topRow, "InputBoxTemplate")
    view.titleInput:SetAutoFocus(false)
    view.titleInput:SetMaxLetters(NOTE_TITLE_MAX_LENGTH)
    view.titleInput:SetFontObject(GameFontHighlightLarge)
    view.titleInput:SetSize(NOTE_TAB_TITLE_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.titleInput:SetPoint("LEFT", 0, 0)
    view.titleInput:SetJustifyH("LEFT")
    view.titleInput:SetTextInsets(0, 0, 0, 0)

    view.metaText = view.topRow:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    view.metaText:SetPoint("LEFT", view.titleInput, "RIGHT", NOTE_TAB_TITLE_TO_META_SPACING, 0)
    view.metaText:SetPoint("RIGHT", view.deleteButton, "LEFT", -12, 0)
    view.metaText:SetJustifyH("LEFT")
    view.metaText:SetJustifyV("MIDDLE")

    view.bodyFrame = CreateFrame("Frame", nil, view)
    view.bodyFrame:SetPoint("TOPLEFT", NOTE_TAB_SIDE_INSET, -(NOTE_TAB_TOP_ROW_TOP_OFFSET + NOTE_TAB_TOP_ROW_HEIGHT + NOTE_TAB_TOP_ROW_TO_BODY_GAP))
    view.bodyFrame:SetPoint("TOPRIGHT", -NOTE_TAB_SIDE_INSET, -(NOTE_TAB_TOP_ROW_TOP_OFFSET + NOTE_TAB_TOP_ROW_HEIGHT + NOTE_TAB_TOP_ROW_TO_BODY_GAP))
    view.bodyFrame:SetPoint("BOTTOMLEFT", NOTE_TAB_SIDE_INSET, NOTE_TAB_BOTTOM_INSET)
    view.bodyFrame:SetPoint("BOTTOMRIGHT", -NOTE_TAB_SIDE_INSET, NOTE_TAB_BOTTOM_INSET)

    view.bodyBackground = view.bodyFrame:CreateTexture(nil, "BACKGROUND")
    view.bodyBackground:SetAllPoints()
    if NOTE_TAB_BODY_BACKGROUND_ATLAS and NOTE_TAB_BODY_BACKGROUND_ATLAS ~= "" then
        view.bodyBackground:SetAtlas(NOTE_TAB_BODY_BACKGROUND_ATLAS, true)
        view.bodyBackground:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_COLOR))
    else
        view.bodyBackground:SetTexture("Interface\\Buttons\\WHITE8x8")
        view.bodyBackground:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_FALLBACK_COLOR))
    end

    view.bodyFallbackFill = view.bodyFrame:CreateTexture(nil, "BACKGROUND", nil, -1)
    view.bodyFallbackFill:SetAllPoints()
    view.bodyFallbackFill:SetTexture("Interface\\Buttons\\WHITE8x8")
    view.bodyFallbackFill:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_FALLBACK_COLOR))
    view.bodyFallbackFill:SetShown(not (NOTE_TAB_BODY_BACKGROUND_ATLAS and NOTE_TAB_BODY_BACKGROUND_ATLAS ~= ""))
    view.bodyFrame:EnableMouse(true)

    noteBodyScrollFrameSerial = noteBodyScrollFrameSerial + 1
    view.bodyScrollFrameName = "SnailStuffNotesBodyScrollFrame" .. tostring(noteBodyScrollFrameSerial)
    view.bodyScrollFrame = CreateFrame("ScrollFrame", view.bodyScrollFrameName, view.bodyFrame, "UIPanelScrollFrameTemplate")
    view.bodyScrollBar = _G[view.bodyScrollFrameName .. "ScrollBar"]

    view.bodyInput = CreateFrame("EditBox", nil, view.bodyScrollFrame)
    view.bodyInput:SetAutoFocus(false)
    view.bodyInput:SetMultiLine(true)
    view.bodyInput:SetMaxLetters(0)
    do
        local fontPath, _, fontFlags = ChatFontNormal:GetFont()
        view.bodyInput:SetFont(fontPath or STANDARD_TEXT_FONT, NOTE_TAB_BODY_EDIT_FONT_SIZE, fontFlags)
    end
    view.bodyInput:SetTextInsets(NOTE_TAB_FIELD_INNER_X, NOTE_TAB_FIELD_INNER_X, NOTE_TAB_FIELD_INNER_Y, NOTE_TAB_FIELD_INNER_Y)
    view.bodyInput:SetJustifyH("LEFT")
    view.bodyInput:SetJustifyV("TOP")
    view.bodyInput:EnableMouse(true)
    view.bodyInput:SetBlinkSpeed(0.5)
    view.bodyInput:ClearAllPoints()
    view.bodyInput:SetPoint("TOPLEFT", view.bodyScrollFrame, "TOPLEFT", 0, 0)
    if view.bodyInput.SetCountInvisibleLetters then
        view.bodyInput:SetCountInvisibleLetters(false)
    end

    view.bodyScrollFrame:SetScrollChild(view.bodyInput)
    view.bodyScrollFrame:EnableMouse(true)
    self:UpdateNoteBodyEditLayout({ panel = { editView = view } })

    return view
end

function module:CreateNoteReadView(parent)
    local view = CreateFrame("Frame", nil, parent)
    view:SetAllPoints()

    view.topRow = CreateFrame("Frame", nil, view)
    view.topRow:SetHeight(NOTE_TAB_TOP_ROW_HEIGHT)
    view.topRow:SetPoint("TOPLEFT", NOTE_TAB_SIDE_INSET, -NOTE_TAB_TOP_ROW_TOP_OFFSET)
    view.topRow:SetPoint("TOPRIGHT", -NOTE_TAB_SIDE_INSET, -NOTE_TAB_TOP_ROW_TOP_OFFSET)

    view.closeButton = CreateFrame("Button", nil, view.topRow, "UIPanelCloseButton")
    view.closeButton:SetSize(NOTE_TAB_TOP_CLOSE_BUTTON_SIZE, NOTE_TAB_TOP_CLOSE_BUTTON_SIZE)
    view.closeButton:ClearAllPoints()
    view.closeButton:SetPoint("RIGHT", view.topRow, "RIGHT", -NOTE_TAB_TOP_ROW_CLOSE_BUTTON_RIGHT_INSET, 0)
    view.closeButton:SetHitRectInsets(
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_LEFT,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_RIGHT,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_TOP,
        NOTE_TAB_TOP_CLOSE_BUTTON_HIT_RECT_BOTTOM
    )

    view.modeButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.modeButton:SetSize(NOTE_TAB_MODE_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.modeButton:SetText("Edit")
    view.modeButton:SetPoint("RIGHT", view.closeButton, "LEFT", -NOTE_TAB_TOP_CLOSE_BUTTON_SPACING, 0)

    view.deleteButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.deleteButton:SetSize(NOTE_TAB_DELETE_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.deleteButton:SetText("Delete")
    view.deleteButton:SetPoint("RIGHT", view.modeButton, "LEFT", -4, 0)

    view.exportButton = CreateFrame("Button", nil, view.topRow, "UIPanelButtonTemplate")
    view.exportButton:SetSize(NOTE_TAB_EXPORT_BUTTON_WIDTH, NOTE_TAB_TOP_ROW_HEIGHT)
    view.exportButton:SetText("Export")
    view.exportButton:SetPoint("RIGHT", view.deleteButton, "LEFT", -4, 0)

    view.titleText = view.topRow:CreateFontString(nil, "ARTWORK", "GameFontHighlightLarge")
    view.titleText:SetWidth(NOTE_TAB_TITLE_WIDTH)
    view.titleText:SetPoint("LEFT", 0, 0)
    view.titleText:SetJustifyH("LEFT")
    view.titleText:SetJustifyV("MIDDLE")

    view.metaText = view.topRow:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    view.metaText:SetPoint("LEFT", view.titleText, "RIGHT", NOTE_TAB_TITLE_TO_META_SPACING, 0)
    view.metaText:SetPoint("RIGHT", view.exportButton, "LEFT", -NOTE_TAB_READ_TITLE_RIGHT_INSET, 0)
    view.metaText:SetJustifyH("LEFT")
    view.metaText:SetJustifyV("MIDDLE")

    view.bodyFrame = CreateFrame("Frame", nil, view)
    view.bodyFrame:SetPoint("TOPLEFT", NOTE_TAB_SIDE_INSET, -(NOTE_TAB_TOP_ROW_TOP_OFFSET + NOTE_TAB_TOP_ROW_HEIGHT + NOTE_TAB_TOP_ROW_TO_BODY_GAP))
    view.bodyFrame:SetPoint("TOPRIGHT", -NOTE_TAB_SIDE_INSET, -(NOTE_TAB_TOP_ROW_TOP_OFFSET + NOTE_TAB_TOP_ROW_HEIGHT + NOTE_TAB_TOP_ROW_TO_BODY_GAP))
    view.bodyFrame:SetPoint("BOTTOMLEFT", NOTE_TAB_SIDE_INSET, NOTE_TAB_BOTTOM_INSET)
    view.bodyFrame:SetPoint("BOTTOMRIGHT", -NOTE_TAB_SIDE_INSET, NOTE_TAB_BOTTOM_INSET)

    view.bodyBackground = view.bodyFrame:CreateTexture(nil, "BACKGROUND")
    view.bodyBackground:SetAllPoints()
    if NOTE_TAB_BODY_BACKGROUND_ATLAS and NOTE_TAB_BODY_BACKGROUND_ATLAS ~= "" then
        view.bodyBackground:SetAtlas(NOTE_TAB_BODY_BACKGROUND_ATLAS, true)
        view.bodyBackground:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_COLOR))
    else
        view.bodyBackground:SetTexture("Interface\\Buttons\\WHITE8x8")
        view.bodyBackground:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_FALLBACK_COLOR))
    end

    view.bodyFallbackFill = view.bodyFrame:CreateTexture(nil, "BACKGROUND", nil, -1)
    view.bodyFallbackFill:SetAllPoints()
    view.bodyFallbackFill:SetTexture("Interface\\Buttons\\WHITE8x8")
    view.bodyFallbackFill:SetVertexColor(unpack(NOTE_TAB_BODY_BACKGROUND_FALLBACK_COLOR))
    view.bodyFallbackFill:SetShown(not (NOTE_TAB_BODY_BACKGROUND_ATLAS and NOTE_TAB_BODY_BACKGROUND_ATLAS ~= ""))

    noteBodyScrollFrameSerial = noteBodyScrollFrameSerial + 1
    view.bodyScrollFrameName = "SnailStuffNotesReadScrollFrame" .. tostring(noteBodyScrollFrameSerial)
    view.bodyScrollFrame = CreateFrame("ScrollFrame", view.bodyScrollFrameName, view.bodyFrame, "UIPanelScrollFrameTemplate")
    view.bodyScrollBar = _G[view.bodyScrollFrameName .. "ScrollBar"]

    view.bodyContent = CreateFrame("Frame", nil, view.bodyScrollFrame)
    view.bodyContent:SetPoint("TOPLEFT", view.bodyScrollFrame, "TOPLEFT", 0, 0)
    view.bodyLines = {}

    view.bodyScrollFrame:SetScrollChild(view.bodyContent)
    view.bodyScrollFrame:EnableMouse(true)

    return view
end

function module:GetOpenTabForNoteId(noteId)
    if not noteId or not self.runtime or not self.runtime.noteSlots then
        return nil
    end

    for _, tab in ipairs(self.runtime.noteSlots) do
        if tab and tab.assigned and tab.noteData and tab.noteData.noteId == noteId then
            return tab
        end
    end

    return nil
end

function module:GetFirstAvailableNoteTabSlot()
    if not self.runtime or not self.runtime.noteSlots then
        return nil
    end

    for slotIndex = 1, MAX_NOTE_TABS do
        local tab = self.runtime.noteSlots[slotIndex]
        if tab and not tab.assigned then
            return slotIndex
        end
    end

    return nil
end

function module:HasAvailableNoteTabSlot()
    return self:GetFirstAvailableNoteTabSlot() ~= nil
end

function module:GetFallbackReusableTabSlot()
    local runtime = self.runtime
    if not runtime or not runtime.noteSlots then
        return 1
    end

    local activeTab = runtime.tabs and runtime.tabs[runtime.activeTabKey]
    if activeTab and activeTab.slotIndex then
        return activeTab.slotIndex
    end

    return 1
end

function module:EnsureSelectedNoteExists()
    local selectedNoteId = self.runtime and self.runtime.selectedNoteId
    if selectedNoteId and not self:GetNoteById(selectedNoteId) then
        self.runtime.selectedNoteId = nil
    end
end

function module:SetSelectedNote(noteId)
    self:EnsureRuntime()
    self.runtime.selectedNoteId = noteId
    self:RefreshHomeList()
end

function module:BuildNextNoteId()
    local store = self:GetNoteStore()
    local nextId = tonumber(store.nextId) or 1
    store.nextId = nextId + 1
    return NOTE_ID_PREFIX .. tostring(nextId)
end

function module:GetUniqueNoteTitle(baseTitle, ignoreNoteId)
    local normalizedTitle = NormalizeNoteTitle(baseTitle)
    local notes = self:GetNotesTable()

    local function titleExists(candidateTitle)
        for noteId, note in pairs(notes) do
            if noteId ~= ignoreNoteId and note and note.title == candidateTitle then
                return true
            end
        end

        return false
    end

    if not titleExists(normalizedTitle) then
        return normalizedTitle
    end

    local suffixIndex = 1
    local candidateTitle = BuildSuffixedNoteTitle(normalizedTitle, suffixIndex)
    while titleExists(candidateTitle) do
        suffixIndex = suffixIndex + 1
        candidateTitle = BuildSuffixedNoteTitle(normalizedTitle, suffixIndex)
    end

    return candidateTitle
end

function module:BuildNoteExportString(noteId)
    local note = noteId and self:GetNoteById(noteId) or nil
    if not note or note.isBuiltin then
        return nil, "Only saved notes can be exported."
    end

    if not AceSerializer or not LibDeflate then
        return nil, "Note export is unavailable."
    end

    local payload = {
        v = NOTE_EXPORT_VERSION,
        t = tostring(note.title or DEFAULT_NOTE_TITLE),
        b = tostring(note.body or DEFAULT_NOTE_BODY),
        c = tonumber(note.createdAt) or time(),
        u = tonumber(note.updatedAt) or tonumber(note.createdAt) or time(),
    }

    local serialized = AceSerializer:Serialize(payload)
    local compressed = LibDeflate:CompressDeflate(serialized)
    if not compressed then
        return nil, "Note export failed."
    end

    local encoded = LibDeflate:EncodeForPrint(compressed)
    if not encoded or encoded == "" then
        return nil, "Note export failed."
    end

    return NOTE_EXPORT_PREFIX .. encoded
end

function module:ParseSerializedImportedNotePayload(serialized)
    if not AceSerializer then
        return nil, "Note import is unavailable."
    end

    if serialized == "" then
        return nil, "The import string is empty."
    end

    local ok, payload = AceSerializer:Deserialize(serialized)
    if not ok then
        return nil, GetPrintableErrorMessage(payload)
    end

    if type(payload) ~= "table" then
        return nil, "The import payload is malformed."
    end

    local version = tonumber(payload.v)
    if version == nil and (payload.t ~= nil or payload.b ~= nil or payload.c ~= nil or payload.u ~= nil) then
        version = NOTE_EXPORT_VERSION
    end
    if version == nil and (payload.title ~= nil or payload.body ~= nil or payload.createdAt ~= nil or payload.updatedAt ~= nil) then
        version = tonumber(payload.version) or NOTE_EXPORT_VERSION
    end
    if version ~= NOTE_EXPORT_VERSION then
        return nil, "This note export version is not supported."
    end

    local title = payload.t
    if title == nil then
        title = payload.title
    end
    if title ~= nil and type(title) ~= "string" then
        return nil, "Imported note title is invalid."
    end

    local body = payload.b
    if body == nil then
        body = payload.body
    end
    if body ~= nil and type(body) ~= "string" then
        return nil, "Imported note body is invalid."
    end

    local createdAt = ClampImportTimestamp(payload.c)
    if createdAt == nil then
        createdAt = ClampImportTimestamp(payload.createdAt)
    end

    local updatedAt = ClampImportTimestamp(payload.u)
    if updatedAt == nil then
        updatedAt = ClampImportTimestamp(payload.updatedAt)
    end

    if createdAt and updatedAt and updatedAt < createdAt then
        updatedAt = createdAt
    end

    return {
        title = NormalizeNoteTitle(title),
        body = body or DEFAULT_NOTE_BODY,
        createdAt = createdAt,
        updatedAt = updatedAt,
    }
end

function module:ParseImportedNoteString(rawText)
    if not AceSerializer then
        return nil, "Note import is unavailable."
    end

    local text = tostring(rawText or "")
    text = string.gsub(text, "^%s+", "")
    text = string.gsub(text, "%s+$", "")
    if text == "" then
        return nil, "Paste a note import string first."
    end

    if string.sub(text, 1, string.len(NOTE_EXPORT_PREFIX)) ~= NOTE_EXPORT_PREFIX then
        return nil, "This string is not a SnailStuff note export."
    end

    local payloadText = string.sub(text, string.len(NOTE_EXPORT_PREFIX) + 1)
    if payloadText == "" then
        return nil, "The import string is empty."
    end

    if LibDeflate then
        local decoded = LibDeflate:DecodeForPrint(payloadText)
        if decoded then
            local decompressed = LibDeflate:DecompressDeflate(decoded)
            if not decompressed then
                return nil, "The import payload could not be decompressed."
            end

            return self:ParseSerializedImportedNotePayload(decompressed)
        end
    end

    return self:ParseSerializedImportedNotePayload(payloadText)
end

function module:CreateImportedNote(importedNote)
    self:EnsureRuntime()

    local now = time()
    local createdAt = importedNote and importedNote.createdAt or now
    local updatedAt = importedNote and importedNote.updatedAt or createdAt
    if updatedAt < createdAt then
        updatedAt = createdAt
    end

    local note = {
        id = self:BuildNextNoteId(),
        title = NormalizeNoteTitle(importedNote and importedNote.title),
        body = tostring(importedNote and importedNote.body or DEFAULT_NOTE_BODY),
        createdAt = createdAt,
        updatedAt = updatedAt,
    }

    self:GetNotesTable()[note.id] = note
    self.runtime.selectedNoteId = note.id
    self:Refresh()
    return note
end

function module:CreateNote(title, body)
    self:EnsureRuntime()

    local noteTitle = self:GetUniqueNoteTitle(title)

    local now = time()
    local note = {
        id = self:BuildNextNoteId(),
        title = noteTitle,
        body = body or DEFAULT_NOTE_BODY,
        createdAt = now,
        updatedAt = now,
    }

    self:GetNotesTable()[note.id] = note
    self.runtime.selectedNoteId = note.id
    self:Refresh()
    return note
end

function module:DuplicateNote(noteId)
    if self:IsBuiltinNoteId(noteId) then
        return nil
    end

    local note = self:GetNoteById(noteId)
    if not note then
        return nil
    end

    return self:CreateNote(note.title, note.body)
end

function module:SetNoteTransferDialogStatus(dialog, text, isError)
    if not dialog or not dialog.statusText then
        return
    end

    dialog.statusText:SetText(text or "")
    if isError then
        dialog.statusText:SetTextColor(1.0, 0.25, 0.25)
    else
        dialog.statusText:SetTextColor(0.80, 0.88, 0.98)
    end
end

function module:CreateNoteTransferDialog(parent)
    local dialog = CreateFrame("Frame", nil, parent, "BasicFrameTemplateWithInset")
    dialog:SetFrameStrata("DIALOG")
    dialog:SetFrameLevel((parent:GetFrameLevel() or 1) + 60)
    dialog:SetSize(NOTE_TRANSFER_DIALOG_WIDTH, NOTE_TRANSFER_DIALOG_HEIGHT)
    dialog:SetPoint("CENTER", parent, "CENTER", 0, 0)
    dialog:Hide()

    if dialog.TitleText then
        dialog.TitleText:SetText("Note Transfer")
    end

    dialog.instructions = dialog:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    dialog.instructions:SetPoint("TOPLEFT", NOTE_TRANSFER_DIALOG_SIDE_INSET, -NOTE_TRANSFER_DIALOG_TOP_INSET - NOTE_TRANSFER_DIALOG_INSTRUCTIONS_TOP_GAP)
    dialog.instructions:SetPoint("TOPRIGHT", -NOTE_TRANSFER_DIALOG_SIDE_INSET, -NOTE_TRANSFER_DIALOG_TOP_INSET - NOTE_TRANSFER_DIALOG_INSTRUCTIONS_TOP_GAP)
    dialog.instructions:SetJustifyH("LEFT")
    dialog.instructions:SetJustifyV("TOP")

    dialog.bodyFrame = CreateBackdropFrame(dialog, false)
    dialog.bodyFrame:SetPoint("TOPLEFT", dialog.instructions, "BOTTOMLEFT", 0, -NOTE_TRANSFER_DIALOG_BODY_TOP_GAP)
    dialog.bodyFrame:SetPoint("TOPRIGHT", dialog.instructions, "BOTTOMRIGHT", 0, -NOTE_TRANSFER_DIALOG_BODY_TOP_GAP)
    dialog.bodyFrame:SetPoint("BOTTOMRIGHT", -NOTE_TRANSFER_DIALOG_SIDE_INSET, NOTE_TRANSFER_DIALOG_BOTTOM_INSET + NOTE_TRANSFER_DIALOG_BUTTON_HEIGHT + NOTE_TRANSFER_DIALOG_BUTTON_TOP_GAP + 24)
    if dialog.bodyFrame.SetBackdropBorderColor then
        dialog.bodyFrame:SetBackdropBorderColor(unpack(HOME_LIST_BORDER_COLOR))
    end

    dialog.bodyBackground = dialog.bodyFrame:CreateTexture(nil, "BACKGROUND")
    dialog.bodyBackground:SetPoint("TOPLEFT", HOME_LIST_BACKDROP_BORDER_MARGIN, -HOME_LIST_BACKDROP_BORDER_MARGIN)
    dialog.bodyBackground:SetPoint("BOTTOMRIGHT", -HOME_LIST_BACKDROP_BORDER_MARGIN, HOME_LIST_BACKDROP_BORDER_MARGIN)
    dialog.bodyBackground:SetTexture("Interface\\Buttons\\WHITE8x8")
    dialog.bodyBackground:SetVertexColor(0.02, 0.02, 0.02, 0.82)

    noteBodyScrollFrameSerial = noteBodyScrollFrameSerial + 1
    dialog.scrollFrameName = "SnailStuffNotesTransferScrollFrame" .. tostring(noteBodyScrollFrameSerial)
    dialog.scrollFrame = CreateFrame("ScrollFrame", dialog.scrollFrameName, dialog.bodyFrame, "UIPanelScrollFrameTemplate")
    dialog.scrollFrame:SetPoint("TOPLEFT", 6, -6)
    dialog.scrollFrame:SetPoint("BOTTOMRIGHT", -28, 6)

    dialog.editBox = CreateFrame("EditBox", nil, dialog.scrollFrame)
    dialog.editBox:SetAutoFocus(false)
    dialog.editBox:SetMultiLine(true)
    dialog.editBox:SetMaxLetters(0)
    do
        local fontPath, _, fontFlags = ChatFontNormal:GetFont()
        dialog.editBox:SetFont(fontPath or STANDARD_TEXT_FONT, NOTE_TAB_BODY_EDIT_FONT_SIZE, fontFlags)
    end
    dialog.editBox:SetTextInsets(NOTE_TRANSFER_DIALOG_EDIT_INNER_X, NOTE_TRANSFER_DIALOG_EDIT_INNER_X, NOTE_TRANSFER_DIALOG_EDIT_INNER_Y, NOTE_TRANSFER_DIALOG_EDIT_INNER_Y)
    dialog.editBox:SetJustifyH("LEFT")
    dialog.editBox:SetJustifyV("TOP")
    dialog.editBox:EnableMouse(true)
    dialog.editBox:SetBlinkSpeed(0.5)
    dialog.editBox:SetWidth(NOTE_TRANSFER_DIALOG_WIDTH - 72)
    dialog.editBox:SetPoint("TOPLEFT", dialog.scrollFrame, "TOPLEFT", 0, 0)
    if dialog.editBox.SetCountInvisibleLetters then
        dialog.editBox:SetCountInvisibleLetters(false)
    end

    dialog.scrollFrame:SetScrollChild(dialog.editBox)
    dialog.scrollFrame:EnableMouse(true)

    dialog.statusText = dialog:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    dialog.statusText:SetPoint("TOPLEFT", dialog.bodyFrame, "BOTTOMLEFT", 2, -NOTE_TRANSFER_DIALOG_STATUS_TOP_GAP)
    dialog.statusText:SetPoint("TOPRIGHT", dialog.bodyFrame, "BOTTOMRIGHT", -2, -NOTE_TRANSFER_DIALOG_STATUS_TOP_GAP)
    dialog.statusText:SetJustifyH("LEFT")
    dialog.statusText:SetJustifyV("TOP")

    dialog.secondaryButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    dialog.secondaryButton:SetSize(NOTE_TRANSFER_DIALOG_BUTTON_WIDTH, NOTE_TRANSFER_DIALOG_BUTTON_HEIGHT)
    dialog.secondaryButton:SetPoint("BOTTOMRIGHT", dialog, "BOTTOMRIGHT", -(NOTE_TRANSFER_DIALOG_SIDE_INSET + NOTE_TRANSFER_DIALOG_BUTTON_WIDTH + 4), NOTE_TRANSFER_DIALOG_BOTTOM_INSET)
    dialog.secondaryButton:SetText(CANCEL)
    dialog.secondaryButton:SetScript("OnClick", function()
        dialog:Hide()
    end)

    dialog.primaryButton = CreateFrame("Button", nil, dialog, "UIPanelButtonTemplate")
    dialog.primaryButton:SetSize(NOTE_TRANSFER_DIALOG_BUTTON_WIDTH, NOTE_TRANSFER_DIALOG_BUTTON_HEIGHT)
    dialog.primaryButton:SetPoint("RIGHT", dialog.secondaryButton, "LEFT", -4, 0)

    if dialog.CloseButton then
        dialog.CloseButton:SetScript("OnClick", function()
            dialog:Hide()
        end)
    end

    dialog.editBox:SetScript("OnEscapePressed", function()
        dialog:Hide()
    end)
    dialog.editBox:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged)
    dialog.editBox:SetScript("OnUpdate", function(editBox, elapsed)
        if ScrollingEdit_OnUpdate then
            ScrollingEdit_OnUpdate(editBox, elapsed, dialog.scrollFrame)
        end
    end)
    dialog.editBox:SetScript("OnTextChanged", function(editBox)
        if ScrollingEdit_OnTextChanged then
            ScrollingEdit_OnTextChanged(editBox, dialog.scrollFrame)
        end
        if dialog.mode == "import" and dialog.statusText and dialog.statusText:GetText() ~= "" then
            module:SetNoteTransferDialogStatus(dialog, "")
        end
    end)
    dialog:SetScript("OnHide", function()
        dialog.mode = nil
        dialog.noteId = nil
        module:SetNoteTransferDialogStatus(dialog, "")
    end)

    return dialog
end

function module:GetNoteTransferDialog()
    if not self.runtime or not self.runtime.frame then
        return nil
    end

    if not self.runtime.noteTransferDialog then
        self.runtime.noteTransferDialog = self:CreateNoteTransferDialog(self.runtime.frame)
    end

    return self.runtime.noteTransferDialog
end

function module:ShowNoteExportDialog(noteId)
    local exportString, err = self:BuildNoteExportString(noteId)
    if not exportString then
        return false, err
    end

    local dialog = self:GetNoteTransferDialog()
    if not dialog then
        return false, "Unable to open export dialog."
    end

    self:HideRowActionMenu()
    self:HideTabContextMenu()

    dialog.mode = "export"
    dialog.noteId = noteId
    dialog:SetFrameLevel((self.runtime.frame:GetFrameLevel() or 1) + 60)
    if dialog.TitleText then
        dialog.TitleText:SetText("Export Note")
    end
    dialog.instructions:SetText("Copy this note export string. It contains the saved title, body, and timestamps for this note.")
    dialog.primaryButton:SetText(CLOSE)
    dialog.primaryButton:ClearAllPoints()
    dialog.primaryButton:SetPoint("BOTTOMRIGHT", dialog, "BOTTOMRIGHT", -NOTE_TRANSFER_DIALOG_SIDE_INSET, NOTE_TRANSFER_DIALOG_BOTTOM_INSET)
    dialog.primaryButton:SetScript("OnClick", function()
        dialog:Hide()
    end)
    dialog.secondaryButton:Hide()
    self:SetNoteTransferDialogStatus(dialog, "")
    dialog:Show()
    dialog.editBox:SetText(exportString)
    dialog.editBox:SetFocus()
    if dialog.editBox.HighlightText then
        dialog.editBox:HighlightText()
    else
        dialog.editBox:SetCursorPosition(0)
    end

    return true
end

function module:ShowNoteImportDialog()
    local dialog = self:GetNoteTransferDialog()
    if not dialog then
        return false
    end

    self:HideRowActionMenu()
    self:HideTabContextMenu()

    dialog.mode = "import"
    dialog.noteId = nil
    dialog:SetFrameLevel((self.runtime.frame:GetFrameLevel() or 1) + 60)
    if dialog.TitleText then
        dialog.TitleText:SetText("Import Note")
    end
    dialog.instructions:SetText("Paste a SnailStuff note export string to create a new local note.")
    dialog.primaryButton:SetText("Import")
    dialog.primaryButton:ClearAllPoints()
    dialog.primaryButton:SetPoint("RIGHT", dialog.secondaryButton, "LEFT", -4, 0)
    dialog.primaryButton:SetScript("OnClick", function()
        local importedNote, err = module:ParseImportedNoteString(dialog.editBox:GetText())
        if not importedNote then
            module:SetNoteTransferDialogStatus(dialog, err, true)
            return
        end

        dialog:Hide()

        local note = module:CreateImportedNote(importedNote)
        if module:HasAvailableNoteTabSlot() then
            module:OpenNote(note.id, false)
        else
            module:SetSelectedNote(note.id)
            module:RefreshHomeList()
        end
    end)
    dialog.secondaryButton:Show()
    dialog.secondaryButton:SetText(CANCEL)
    self:SetNoteTransferDialogStatus(dialog, "")
    dialog:Show()
    dialog.editBox:SetText("")
    dialog.editBox:SetFocus()
    dialog.editBox:SetCursorPosition(0)

    return true
end

function module:DeleteNote(noteId)
    self:EnsureRuntime()

    if not noteId or self:IsBuiltinNoteId(noteId) then
        return
    end

    local notes = self:GetNotesTable()
    if not notes[noteId] then
        return
    end

    notes[noteId] = nil
    self:CloseTabsForNote(noteId)

    if self.runtime and self.runtime.selectedNoteId == noteId then
        self.runtime.selectedNoteId = nil
    end

    self:HideRowActionMenu()
    self:Refresh()
end

function module:ConfirmDeleteNoteFromTab(tab)
    local noteId = tab and tab.noteData and tab.noteData.noteId or nil
    if not noteId or self:IsBuiltinNoteId(noteId) then
        return
    end

    StaticPopup_Show("SNAILSTUFF_NOTES_CONFIRM_DELETE", nil, nil, {
        noteId = noteId,
    })
end

function module:CreateAndOpenNote()
    self:EnsureRuntime()

    local targetSlotIndex = self:GetFirstAvailableNoteTabSlot() or self:GetFallbackReusableTabSlot()
    local tab = self.runtime and self.runtime.noteSlots and self.runtime.noteSlots[targetSlotIndex]
    if not tab then
        return
    end

    local function assignUnsavedNote()
        tab.assigned = true
        tab.mode = "edit"
        tab.noteData = {
            noteId = nil,
            title = DEFAULT_NOTE_TITLE,
            body = DEFAULT_NOTE_BODY,
            createdAt = nil,
            updatedAt = nil,
        }

        self:SetSelectedNote(nil)
        self:RefreshNotePanel(tab)
        self:SetNoteTabDirty(tab, true)
        self:RefreshTabLayout()
        self:SelectTab(tab.key)

        local view = self:GetNoteTabEditView(tab.panel)
        if view and view.bodyInput then
            view.bodyInput:SetFocus()
            view.bodyInput:SetCursorPosition(0)
        end
    end

    self:ConfirmDiscardIfDirty(tab, assignUnsavedNote)
end

function module:CreateHomeListRow(parent, index)
    local row = CreateFrame("Button", nil, parent)
    row:SetHeight(HOME_ROW_HEIGHT)
    row:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
    row:SetHighlightTexture("Interface\\Buttons\\WHITE8x8")
    row:GetHighlightTexture():SetVertexColor(1, 1, 1, 0)

    row.background = CreateSolidTexture(row, "BACKGROUND", HOME_ROW_BACKGROUND_COLOR)
    row.background:SetAllPoints()

    row.hoverTexture = CreateSolidTexture(row, "ARTWORK", HOME_ROW_HOVER_COLOR)
    row.hoverTexture:SetAllPoints()
    row.hoverTexture:Hide()

    row.selectedTexture = CreateSolidTexture(row, "ARTWORK", HOME_ROW_SELECTED_COLOR)
    row.selectedTexture:SetAllPoints()
    row.selectedTexture:Hide()

    row.title = row:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    row.title:SetPoint("LEFT", HOME_ROW_TEXT_SIDE_INSET, HOME_ROW_TITLE_VERTICAL_OFFSET)
    row.title:SetPoint("RIGHT", row, "RIGHT", -(HOME_ROW_TIMESTAMP_RIGHT_INSET + HOME_ROW_TIMESTAMP_WIDTH + HOME_ROW_TITLE_TO_TIMESTAMP_SPACING), HOME_ROW_TITLE_VERTICAL_OFFSET)
    row.title:SetJustifyH("LEFT")
    row.title:SetJustifyV("MIDDLE")
    row.title:SetWordWrap(false)
    row.title:SetFont(STANDARD_TEXT_FONT, HOME_ROW_TITLE_FONT_SIZE, "")

    row.timestamp = row:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    row.timestamp:SetWidth(HOME_ROW_TIMESTAMP_WIDTH)
    row.timestamp:SetPoint("RIGHT", -HOME_ROW_TIMESTAMP_RIGHT_INSET, HOME_ROW_TEXT_VERTICAL_OFFSET)
    row.timestamp:SetJustifyH("RIGHT")
    row.timestamp:SetJustifyV("MIDDLE")
    row.timestamp:SetWordWrap(false)
    row.timestamp:SetFont(STANDARD_TEXT_FONT, HOME_ROW_TIMESTAMP_FONT_SIZE, "")

    row:SetScript("OnEnter", function(selfRow)
        module.runtime.hoveredNoteId = selfRow.noteId
        module:RefreshHomeRowVisuals(selfRow)
    end)
    row:SetScript("OnLeave", function(selfRow)
        if module.runtime.hoveredNoteId == selfRow.noteId then
            module.runtime.hoveredNoteId = nil
        end
        module:RefreshHomeRowVisuals(selfRow)
    end)
    row:SetScript("OnClick", function(selfRow, button)
        if not selfRow.noteId then
            return
        end

        if button == "RightButton" then
            module:SetSelectedNote(selfRow.noteId)
            module:ShowRowActionMenu(selfRow, selfRow.noteId)
            return
        end

        if button == "MiddleButton" then
            module:HideRowActionMenu()
            module:OpenNote(selfRow.noteId, true, true)
            return
        end

        module:HideRowActionMenu()
        module:OpenNote(selfRow.noteId, false)
    end)

    return row
end

function module:GetVisibleHomeRowCount(panel)
    if not panel or not panel.listBody then
        return 0
    end

    local availableHeight = math.max(panel.listBody:GetHeight(), HOME_ROW_HEIGHT)
    return math.max(1, math.floor((availableHeight + HOME_ROW_SPACING) / ROW_STRIDE))
end

function module:NeedsHomeScrollbar(panel, noteCount)
    if not panel then
        return false
    end

    return (tonumber(noteCount) or 0) > self:GetVisibleHomeRowCount(panel)
end

function module:ApplyHomeListWidth(panel, hasScrollbar)
    if not panel then
        return
    end

    local rightInset = hasScrollbar and HOME_LIST_SCROLLBAR_TOTAL_WIDTH or 0

    if panel.scrollFrame then
        panel.scrollFrame:ClearAllPoints()
        panel.scrollFrame:SetPoint("TOPLEFT", panel.listBody, "TOPLEFT", 0, 0)
        panel.scrollFrame:SetPoint("BOTTOMRIGHT", panel.listBody, "BOTTOMRIGHT", -rightInset, 0)
        panel.scrollFrame:SetShown(hasScrollbar)
    end

    if not panel.rows then
        return
    end

    for _, row in ipairs(panel.rows) do
        row:ClearAllPoints()
        row:SetPoint("LEFT", 0, 0)
        row:SetPoint("RIGHT", -rightInset, 0)
    end

    for index, row in ipairs(panel.rows) do
        if index == 1 then
            row:SetPoint("TOPLEFT", panel.rowContainer, "TOPLEFT", 0, 0)
        else
            row:SetPoint("TOPLEFT", panel.rows[index - 1], "BOTTOMLEFT", 0, -HOME_ROW_SPACING)
        end
    end
end

function module:UpdateHomeRowPool(panel, visibleRowCount)
    if not panel or not panel.rows then
        return
    end

    for index, row in ipairs(panel.rows) do
        if index <= visibleRowCount then
            row:Show()
        else
            row.noteId = nil
            row:Hide()
        end
    end
end

function module:EnsureHomeRows(panel)
    panel.rows = panel.rows or {}

    local desiredRowCount = self:GetVisibleHomeRowCount(panel)
    for index = #panel.rows + 1, desiredRowCount do
        local row = self:CreateHomeListRow(panel.rowContainer, index)
        if index == 1 then
            row:SetPoint("TOPLEFT", panel.rowContainer, "TOPLEFT", 0, 0)
        else
            row:SetPoint("TOPLEFT", panel.rows[index - 1], "BOTTOMLEFT", 0, -HOME_ROW_SPACING)
        end
        panel.rows[index] = row
    end
end

function module:RefreshHomeRowVisuals(row)
    if not row or not row.noteId then
        return
    end

    local isSelected = self.runtime and self.runtime.selectedNoteId == row.noteId
    local isHovered = self.runtime and self.runtime.hoveredNoteId == row.noteId

    row.selectedTexture:SetShown(isSelected)
    row.hoverTexture:SetShown(isHovered and not isSelected)

    if isSelected then
        row.title:SetTextColor(1, 0.93, 0.65)
    else
        row.title:SetTextColor(0.93, 0.90, 0.84)
    end
end

function module:RefreshHomeHeader(panel, noteCount)
    if not panel or not panel.countText then
        return
    end

    if noteCount == 1 then
        panel.countText:SetText("1 note")
    else
        panel.countText:SetText(string.format("%d notes", noteCount))
    end
end

function module:RefreshHomeList()
    local runtime = self.runtime
    local homeTab = runtime and runtime.tabs and runtime.tabs.home
    local panel = homeTab and homeTab.panel
    if not panel or not panel.scrollFrame then
        return
    end

    self:EnsureSelectedNoteExists()
    self:EnsureHomeRows(panel)

    local notes = self:GetOrderedNotes()
    local noteCount = #notes
    local visibleRowCount = math.max(1, self:GetVisibleHomeRowCount(panel))
    local hasScrollbar = self:NeedsHomeScrollbar(panel, noteCount)
    local scrollOffset = FauxScrollFrame_GetOffset(panel.scrollFrame) or 0

    FauxScrollFrame_Update(panel.scrollFrame, noteCount, visibleRowCount, ROW_STRIDE)
    self:ApplyHomeListWidth(panel, hasScrollbar)
    self:UpdateHomeRowPool(panel, visibleRowCount)
    scrollOffset = math.min(scrollOffset, math.max(0, noteCount - visibleRowCount))

    self:RefreshHomeHeader(panel, noteCount)

    panel.emptyState:SetShown(noteCount == 0)

    if noteCount == 0 then
        self:HideRowActionMenu()
    end

    local actionMenuNoteVisible = false

    for rowIndex, row in ipairs(panel.rows) do
        local noteIndex = scrollOffset + rowIndex
        local note = notes[noteIndex]

        if note then
            row.noteId = note.id
            row.title:SetText(note.title or DEFAULT_NOTE_TITLE)
            if note.isBuiltin then
                row.title:SetJustifyH("CENTER")
                row.title:ClearAllPoints()
                row.title:SetPoint("LEFT", row, "LEFT", HOME_ROW_TEXT_SIDE_INSET + HOME_ROW_BUILTIN_TITLE_CENTER_OFFSET_X, HOME_ROW_TITLE_VERTICAL_OFFSET)
                row.title:SetPoint("RIGHT", row, "RIGHT", -(HOME_ROW_TEXT_SIDE_INSET - HOME_ROW_BUILTIN_TITLE_CENTER_OFFSET_X), HOME_ROW_TITLE_VERTICAL_OFFSET)
            else
                row.title:SetJustifyH("LEFT")
                row.title:ClearAllPoints()
                row.title:SetPoint("LEFT", HOME_ROW_TEXT_SIDE_INSET, HOME_ROW_TITLE_VERTICAL_OFFSET)
                row.title:SetPoint("RIGHT", row, "RIGHT", -(HOME_ROW_TIMESTAMP_RIGHT_INSET + HOME_ROW_TIMESTAMP_WIDTH + HOME_ROW_TITLE_TO_TIMESTAMP_SPACING), HOME_ROW_TITLE_VERTICAL_OFFSET)
            end
            if note.isBuiltin then
                row.timestamp:SetText("")
            else
                row.timestamp:SetText(FormatSmartTimestamp(note.updatedAt, note.createdAt))
            end
            row:Show()
            self:RefreshHomeRowVisuals(row)

            if runtime.rowActionMenu and runtime.rowActionMenu:IsShown() and runtime.rowActionMenu.noteId == note.id then
                actionMenuNoteVisible = true
                runtime.rowActionMenu.currentRow = row
                self:RefreshRowActionMenu()
            end
        else
            row.noteId = nil
            row.title:SetJustifyH("LEFT")
            row.title:ClearAllPoints()
            row.title:SetPoint("LEFT", HOME_ROW_TEXT_SIDE_INSET, HOME_ROW_TITLE_VERTICAL_OFFSET)
            row.title:SetPoint("RIGHT", row, "RIGHT", -(HOME_ROW_TIMESTAMP_RIGHT_INSET + HOME_ROW_TIMESTAMP_WIDTH + HOME_ROW_TITLE_TO_TIMESTAMP_SPACING), HOME_ROW_TITLE_VERTICAL_OFFSET)
            row:Hide()
        end
    end

    if runtime.rowActionMenu and runtime.rowActionMenu:IsShown() and not actionMenuNoteVisible then
        self:HideRowActionMenu()
    end
end

function module:RefreshHomeView()
    self:RefreshHomeList()
end

function module:CreateHomePanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    panel.countText = panel:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    panel.countText:SetPoint("TOPLEFT", HOME_HEADER_SIDE_INSET, -HOME_HEADER_TOP_INSET - HOME_HEADER_COUNT_TOP_OFFSET)
    panel.countText:SetJustifyH("LEFT")
    panel.countText:SetJustifyV("MIDDLE")

    panel.newButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.newButton:SetSize(HOME_BUTTON_WIDTH, HOME_BUTTON_HEIGHT)
    panel.newButton:SetPoint("TOPRIGHT", -HOME_HEADER_SIDE_INSET, -HOME_HEADER_TOP_INSET)
    panel.newButton:SetText("New")
    panel.newButton:SetScript("OnClick", function()
        module:HideRowActionMenu()
        module:CreateAndOpenNote()
    end)

    panel.importButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    panel.importButton:SetSize(HOME_BUTTON_WIDTH, HOME_BUTTON_HEIGHT)
    panel.importButton:SetPoint("RIGHT", panel.newButton, "LEFT", -HOME_HEADER_BUTTON_SPACING, 0)
    panel.importButton:SetPoint("TOP", panel.newButton, "TOP", 0, 0)
    panel.importButton:SetText("Import")
    panel.importButton:SetScript("OnClick", function()
        module:ShowNoteImportDialog()
    end)

    panel.listFrame = CreateBackdropFrame(panel, false)
    panel.listFrame:SetPoint("TOPLEFT", HOME_LIST_FRAME_INSET, -HOME_LIST_TOP_INSET)
    panel.listFrame:SetPoint("BOTTOMRIGHT", -HOME_LIST_FRAME_INSET, HOME_LIST_BOTTOM_INSET)
    if panel.listFrame.SetBackdropBorderColor then
        panel.listFrame:SetBackdropBorderColor(unpack(HOME_LIST_BORDER_COLOR))
    end

    panel.listBackground = panel.listFrame:CreateTexture(nil, "BACKGROUND")
    panel.listBackground:SetPoint("TOPLEFT", HOME_LIST_BACKDROP_BORDER_MARGIN, -HOME_LIST_BACKDROP_BORDER_MARGIN)
    panel.listBackground:SetPoint("BOTTOMRIGHT", -HOME_LIST_BACKDROP_BORDER_MARGIN, HOME_LIST_BACKDROP_BORDER_MARGIN)
    panel.listBackground:SetAtlas(HOME_LIST_BACKGROUND_ATLAS, true)
    panel.listBackground:SetVertexColor(unpack(HOME_LIST_BACKGROUND_COLOR))

    panel.listClip = CreateFrame("Frame", nil, panel.listFrame)
    panel.listClip:SetPoint("TOPLEFT", HOME_LIST_BACKDROP_BORDER_MARGIN, -HOME_LIST_BACKDROP_BORDER_MARGIN)
    panel.listClip:SetPoint("BOTTOMRIGHT", -HOME_LIST_BACKDROP_BORDER_MARGIN, HOME_LIST_BACKDROP_BORDER_MARGIN + 8)
    if panel.listClip.SetClipsChildren then
        panel.listClip:SetClipsChildren(true)
    end

    panel.listBody = CreateFrame("Frame", nil, panel.listClip)
    panel.listBody:SetPoint("TOPLEFT", HOME_LIST_INNER_PADDING, -HOME_LIST_INNER_PADDING)
    panel.listBody:SetPoint("BOTTOMRIGHT", -HOME_LIST_INNER_PADDING, HOME_LIST_INNER_PADDING)
    panel.listBody:SetScript("OnSizeChanged", function()
        module:RefreshHomeList()
    end)

    panel.rowContainer = CreateFrame("Frame", nil, panel.listBody)
    panel.rowContainer:SetPoint("TOPLEFT", 0, 0)
    panel.rowContainer:SetPoint("TOPRIGHT", 0, 0)
    panel.rowContainer:SetPoint("BOTTOMLEFT", 0, 0)
    panel.rowContainer:SetPoint("BOTTOMRIGHT", 0, 0)

    panel.scrollFrame = CreateFrame("ScrollFrame", nil, panel.listClip, "FauxScrollFrameTemplate")
    panel.scrollFrame:SetPoint("TOPLEFT", panel.listBody, "TOPLEFT", 0, 0)
    panel.scrollFrame:SetPoint("BOTTOMRIGHT", panel.listBody, "BOTTOMRIGHT", -HOME_LIST_SCROLLBAR_TOTAL_WIDTH, 0)
    panel.scrollFrame:SetScript("OnVerticalScroll", function(selfFrame, offset)
        FauxScrollFrame_OnVerticalScroll(selfFrame, offset, ROW_STRIDE, function()
            module:RefreshHomeList()
        end)
    end)

    panel.emptyState = CreateFrame("Button", nil, panel.listBody)
    panel.emptyState:SetSize(EMPTY_STATE_WIDTH, EMPTY_STATE_HEIGHT)
    panel.emptyState:SetPoint("CENTER", 0, 0)
    panel.emptyState:RegisterForClicks("LeftButtonUp")
    panel.emptyState:SetScript("OnClick", function(_, button)
        if button == "LeftButton" then
            module:CreateAndOpenNote()
        end
    end)

    panel.emptyStateBackdrop = CreateBackdropFrame(panel.emptyState)
    panel.emptyStateBackdrop:SetAllPoints()
    if panel.emptyStateBackdrop.SetBackdropColor then
        panel.emptyStateBackdrop:SetBackdropColor(0.08, 0.08, 0.08, 0.35)
    end
    if panel.emptyStateBackdrop.SetBackdropBorderColor then
        panel.emptyStateBackdrop:SetBackdropBorderColor(0.28, 0.28, 0.28, 0.55)
    end

    panel.emptyStateText = panel.emptyState:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
    panel.emptyStateText:SetWidth(EMPTY_STATE_MESSAGE_WIDTH)
    panel.emptyStateText:SetPoint("CENTER", 0, 0)
    panel.emptyStateText:SetJustifyH("CENTER")
    panel.emptyStateText:SetJustifyV("MIDDLE")
    panel.emptyStateText:SetSpacing(4)
    panel.emptyStateText:SetText("No notes yet.\nClick here to create your first note!")

    panel.emptyState:SetScript("OnEnter", function()
        panel.emptyStateText:SetTextColor(1, 0.93, 0.65)
    end)
    panel.emptyState:SetScript("OnLeave", function()
        panel.emptyStateText:SetTextColor(0.93, 0.90, 0.84)
    end)

    panel.rows = {}

    return panel
end

function module:CreateNotePanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    panel.viewHost = CreateFrame("Frame", nil, panel)
    panel.viewHost:SetAllPoints()

    panel.readView = self:CreateNoteReadView(panel.viewHost)
    panel.editView = self:CreateNoteEditView(panel.viewHost)
    panel.activeView = panel.editView
    panel.readView:Hide()

    return panel
end

function module:SetTabTitle(tab, title)
    if not tab or not tab.button then
        return
    end

    tab.title = title or "Note"
    tab.button:SetText(tab.title)
    if PanelTemplates_TabResize then
        PanelTemplates_TabResize(tab.button, 0)
    end
end

function module:SetTabSelected(tab, selected)
    if not tab or not tab.button then
        return
    end

    tab.selected = selected and true or false

    if tab.selected then
        if PanelTemplates_SelectTab then
            PanelTemplates_SelectTab(tab.button)
        end
    else
        if PanelTemplates_DeselectTab then
            PanelTemplates_DeselectTab(tab.button)
        end
    end
end

function module:IsTabVisible(tab)
    return tab and (tab.key == "home" or tab.assigned) or false
end

function module:RefreshTabLayout()
    local runtime = self.runtime
    if not runtime or not runtime.frame then
        return
    end

    local previousButton
    for _, tab in ipairs(runtime.orderedTabs) do
        local visible = self:IsTabVisible(tab)
        tab.button:ClearAllPoints()
        tab.button:SetShown(visible)
        tab.content:SetShown(visible and runtime.activeTabKey == tab.key)

        if visible then
            if previousButton then
                tab.button:SetPoint("LEFT", previousButton, "RIGHT", TAB_SPACING, 0)
            else
                tab.button:SetPoint("BOTTOMLEFT", runtime.frame.tabBar, "BOTTOMLEFT", 0, 0)
            end
            previousButton = tab.button
        end
    end
end

function module:SelectTab(tabKey)
    local runtime = self.runtime
    local tab = runtime and runtime.tabs and runtime.tabs[tabKey]
    if not runtime or not tab or not self:IsTabVisible(tab) then
        return
    end

    runtime.activeTabKey = tabKey
    self:HideRowActionMenu()
    self:HideTabContextMenu()

    for _, entry in ipairs(runtime.orderedTabs) do
        local visible = self:IsTabVisible(entry)
        entry.content:SetShown(visible and entry.key == tabKey)
        self:SetTabSelected(entry, entry.key == tabKey)
    end

    if runtime.frame then
        self:ApplyWindowGeometry(runtime.frame)
    end

    if tabKey == "home" then
        self:RefreshHomeView()
    elseif tab.slotIndex then
        self:RefreshNoteTabControls(tab)
        self:ApplyTabMode(tab)
    end
end

function module:CreateTab(frame, definition, index)
    local buttonName = (frame:GetName() or "SnailStuffNotesFrame") .. "Tab" .. index
    local button = CreateFrame("Button", buttonName, frame, "CharacterFrameTabButtonTemplate")
    button:SetParent(frame.tabBar)
    button:SetID(index)
    button:SetFrameStrata(frame:GetFrameStrata())
    button:SetFrameLevel((frame:GetFrameLevel() or 1) + 8)
    button:SetHeight(TAB_HEIGHT)
    button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    button.text = button.GetFontString and button:GetFontString() or button.Text

    local content = CreateFrame("Frame", nil, frame.contentHost)
    content:SetAllPoints()
    content:Hide()

    local tab = {
        key = definition.key,
        title = definition.title,
        button = button,
        content = content,
        slotIndex = definition.slotIndex,
        assigned = definition.key == "home",
        selected = false,
        noteData = nil,
        panel = nil,
    }

    if definition.key == "home" then
        tab.panel = self:CreateHomePanel(content)
    else
        tab.panel = self:CreateNotePanel(content)
        local view = self:GetNoteTabEditView(tab.panel)
        local readView = self:GetNoteTabReadView(tab.panel)
        if view then
            view.saveButton:SetScript("OnClick", function()
                module:SaveNoteTab(tab)
            end)
            view.deleteButton:SetScript("OnClick", function()
                module:ConfirmDeleteNoteFromTab(tab)
            end)
            view.modeButton:SetScript("OnClick", function()
                module:HandleNoteModeButtonClicked(tab)
            end)
            view.closeButton:SetScript("OnClick", function()
                module:ConfirmDiscardIfDirty(tab, function()
                    module:CloseTab(tab)
                end)
            end)
            view.titleInput:SetScript("OnEscapePressed", function(editBox)
                editBox:ClearFocus()
            end)
            view.titleInput:SetScript("OnEnterPressed", function(editBox)
                editBox:ClearFocus()
                module:SaveNoteTab(tab)
            end)
            view.titleInput:SetScript("OnTextChanged", function(_, userInput)
                if userInput then
                    module:HandleNoteTabContentChanged(tab)
                end
            end)

            view.bodyInput:SetScript("OnEscapePressed", function(editBox)
                editBox:ClearFocus()
            end)
            view.bodyInput:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged)
            view.bodyInput:SetScript("OnUpdate", function(editBox, elapsed)
                if ScrollingEdit_OnUpdate then
                    ScrollingEdit_OnUpdate(editBox, elapsed, view.bodyScrollFrame)
                end
            end)
            view.bodyInput:SetScript("OnTextChanged", function(editBox, userInput)
                if ScrollingEdit_OnTextChanged then
                    ScrollingEdit_OnTextChanged(editBox, view.bodyScrollFrame)
                end
                if userInput then
                    module:HandleNoteTabContentChanged(tab)
                end
            end)
            view.bodyInput:SetScript("OnEditFocusLost", function(editBox)
                editBox:HighlightText(0, 0)
            end)
            view.bodyInput:SetScript("OnReceiveDrag", function(editBox)
                module:HandleNoteBodyItemDrop(tab, editBox)
            end)
            view.bodyScrollFrame:SetScript("OnReceiveDrag", function()
                module:HandleNoteBodyItemDrop(tab)
            end)
            view.bodyFrame:SetScript("OnReceiveDrag", function()
                module:HandleNoteBodyItemDrop(tab)
            end)
            view.bodyScrollFrame:SetScript("OnMouseDown", function(_, button)
                if button ~= "LeftButton" then
                    return
                end

                local text = view.bodyInput:GetText() or ""
                if text ~= "" then
                    return
                end

                view.bodyInput:SetFocus()
                view.bodyInput:SetCursorPosition(0)
            end)
            view.bodyFrame:SetScript("OnSizeChanged", function()
                module:UpdateNoteBodyEditLayout(tab)
            end)
            view:SetScript("OnShow", function()
                module:UpdateNoteBodyEditLayout(tab)
            end)
        end
        if readView then
            readView.exportButton:SetScript("OnClick", function()
                local noteId = tab and tab.noteData and tab.noteData.noteId or nil
                if noteId then
                    module:ShowNoteExportDialog(noteId)
                end
            end)
            readView.deleteButton:SetScript("OnClick", function()
                module:ConfirmDeleteNoteFromTab(tab)
            end)
            readView.modeButton:SetScript("OnClick", function()
                module:HandleNoteModeButtonClicked(tab)
            end)
            readView.closeButton:SetScript("OnClick", function()
                module:ConfirmDiscardIfDirty(tab, function()
                    module:CloseTab(tab)
                end)
            end)
            readView.bodyFrame:SetScript("OnSizeChanged", function()
                module:UpdateNoteBodyReadLayout(tab)
            end)
            readView:SetScript("OnShow", function()
                module:RefreshNoteReadView(tab)
                module:QueueDeferredNoteReadViewRefresh(tab)
            end)
        end
    end

    button:SetScript("OnClick", function(_, mouseButton)
        if mouseButton == "RightButton" then
            if tab.key ~= "home" then
                module:ShowTabContextMenu(tab)
            end
            return
        end

        module:SelectTab(tab.key)
    end)

    self:SetTabTitle(tab, definition.title)
    self:SetTabSelected(tab, false)

    return tab
end

function module:CreateRowActionMenuButton(parent, label, orderIndex, callback)
    local button = CreateFrame("Button", nil, parent)
    button:SetHeight(ROW_MENU_BUTTON_HEIGHT)
    button:SetPoint("LEFT", ROW_MENU_PADDING, 0)
    button:SetPoint("RIGHT", -ROW_MENU_PADDING, 0)
    if orderIndex == 1 then
        button:SetPoint("TOP", 0, -ROW_MENU_PADDING)
    else
        button:SetPoint("TOP", parent.buttons[orderIndex - 1], "BOTTOM", 0, -ROW_MENU_SPACING)
    end

    button.background = CreateSolidTexture(button, "BACKGROUND", { 0, 0, 0, 0 })
    button.background:SetAllPoints()

    button.highlight = CreateSolidTexture(button, "ARTWORK", ROW_MENU_BUTTON_HOVER_COLOR)
    button.highlight:SetAllPoints()
    button.highlight:Hide()

    button.text = button:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    button.text:SetPoint("LEFT", 8, 0)
    button.text:SetPoint("RIGHT", -8, 0)
    button.text:SetJustifyH("LEFT")
    button.text:SetText(label)

    button:SetScript("OnEnter", function(selfButton)
        if not selfButton.disabled then
            selfButton.highlight:Show()
        end
    end)
    button:SetScript("OnLeave", function(selfButton)
        selfButton.highlight:Hide()
    end)
    button:SetScript("OnClick", function(selfButton)
        if selfButton.disabled then
            return
        end

        callback()
    end)

    return button
end

function module:CreateRowActionMenu(parent)
    local menu = CreateFrame("Frame", nil, parent)
    menu:SetFrameStrata("DIALOG")
    menu:SetFrameLevel((parent:GetFrameLevel() or 1) + 40)
    menu:SetWidth(ROW_MENU_WIDTH)

    menu.background = menu:CreateTexture(nil, "BACKGROUND")
    menu.background:SetAllPoints()
    menu.background:SetTexture(ROW_MENU_BACKGROUND_TEXTURE)
    menu.background:SetVertexColor(unpack(ROW_MENU_BACKGROUND_COLOR))

    menu:Hide()

    menu.buttons = {}

    menu.buttons[1] = self:CreateRowActionMenuButton(menu, "Open", 1, function()
        local noteId = menu.noteId
        menu:Hide()
        module:OpenNote(noteId, false)
    end)

    menu.buttons[2] = self:CreateRowActionMenuButton(menu, "Open in new tab", 2, function()
        local noteId = menu.noteId
        menu:Hide()
        module:OpenNote(noteId, true, true)
    end)

    menu.buttons[3] = self:CreateRowActionMenuButton(menu, "Export", 3, function()
        local noteId = menu.noteId
        menu:Hide()
        module:ShowNoteExportDialog(noteId)
    end)

    menu.buttons[4] = self:CreateRowActionMenuButton(menu, "Duplicate", 4, function()
        local noteId = menu.noteId
        menu:Hide()
        module:DuplicateNote(noteId)
    end)

    menu.buttons[5] = self:CreateRowActionMenuButton(menu, "Delete", 5, function()
        local noteId = menu.noteId
        menu:Hide()
        module:DeleteNote(noteId)
    end)

    menu:SetHeight((ROW_MENU_PADDING * 2) + (ROW_MENU_BUTTON_HEIGHT * #menu.buttons) + (ROW_MENU_SPACING * (#menu.buttons - 1)))
    menu:SetScript("OnHide", function()
        menu.noteId = nil
        menu.currentRow = nil
    end)

    return menu
end

function module:RefreshRowActionMenu()
    local menu = self.runtime and self.runtime.rowActionMenu
    if not menu or not menu:IsShown() then
        return
    end

    local disableNewTab = not self:HasAvailableNoteTabSlot()
    local newTabButton = menu.buttons and menu.buttons[2]
    if newTabButton then
        newTabButton.disabled = disableNewTab
        newTabButton:EnableMouse(not disableNewTab)
        newTabButton.highlight:Hide()
        if disableNewTab then
            newTabButton.text:SetTextColor(0.50, 0.50, 0.50)
        else
            newTabButton.text:SetTextColor(0.93, 0.90, 0.84)
        end
    end
end

function module:ShowRowActionMenu(row, noteId)
    if not row or not noteId or self:IsBuiltinNoteId(noteId) or not self.runtime or not self.runtime.rowActionMenu then
        return
    end

    self:HideTabContextMenu()

    local menu = self.runtime.rowActionMenu
    menu.noteId = noteId
    menu.currentRow = row
    menu:ClearAllPoints()
    menu:SetPoint("TOPRIGHT", row, "TOPRIGHT", ROW_MENU_ANCHOR_X, ROW_MENU_ANCHOR_Y)
    menu:Show()
    self:RefreshRowActionMenu()
end

function module:HideRowActionMenu()
    local menu = self.runtime and self.runtime.rowActionMenu
    if menu and menu:IsShown() then
        menu:Hide()
    end
end

function module:CreateTabContextMenu(parent)
    local menu = CreateFrame("Frame", nil, parent)
    menu:SetFrameStrata("DIALOG")
    menu:SetFrameLevel((parent:GetFrameLevel() or 1) + 40)
    menu:SetWidth(ROW_MENU_WIDTH)

    menu.background = menu:CreateTexture(nil, "BACKGROUND")
    menu.background:SetAllPoints()
    menu.background:SetTexture(ROW_MENU_BACKGROUND_TEXTURE)
    menu.background:SetVertexColor(unpack(ROW_MENU_BACKGROUND_COLOR))

    menu:Hide()
    menu.buttons = {}

    menu.buttons[1] = self:CreateRowActionMenuButton(menu, "Close Tab", 1, function()
        local targetTab = menu.targetTab
        menu:Hide()
        if targetTab then
            module:ConfirmDiscardIfDirty(targetTab, function()
                module:CloseTab(targetTab)
            end)
        end
    end)

    menu:SetHeight((ROW_MENU_PADDING * 2) + ROW_MENU_BUTTON_HEIGHT)
    menu:SetScript("OnHide", function()
        menu.targetTab = nil
        menu.targetButton = nil
    end)

    return menu
end

function module:ShowTabContextMenu(tab)
    if not tab or tab.key == "home" or not tab.button or not self.runtime or not self.runtime.tabContextMenu then
        return
    end

    self:HideRowActionMenu()

    local menu = self.runtime.tabContextMenu
    menu.targetTab = tab
    menu.targetButton = tab.button
    menu:ClearAllPoints()
    menu:SetPoint("TOPRIGHT", tab.button, "BOTTOMRIGHT", 0, -2)
    menu:Show()
end

function module:HideTabContextMenu()
    local menu = self.runtime and self.runtime.tabContextMenu
    if menu and menu:IsShown() then
        menu:Hide()
    end
end

function module:OpenAssignedNoteTab(slotIndex, note, keepCurrentTabActive)
    self:EnsureRuntime()

    local tab = self.runtime.noteSlots and self.runtime.noteSlots[slotIndex]
    if not tab or not note then
        return
    end

    local function assignNote()
        tab.assigned = true
        tab.mode = "read"
        tab.noteData = {
            noteId = note.id,
            title = NormalizeNoteTitle(note.title),
            body = note.body or DEFAULT_NOTE_BODY,
            createdAt = note.createdAt,
            updatedAt = note.updatedAt,
        }

        self:RefreshNotePanel(tab)
        self:RefreshTabLayout()
        if not keepCurrentTabActive then
            self:SelectTab(tab.key)
        end
    end

    local isReplacingDifferentNote = tab.assigned and tab.noteData and tab.noteData.noteId ~= note.id
    if isReplacingDifferentNote then
        self:ConfirmDiscardIfDirty(tab, assignNote)
        return
    end

    assignNote()
end

function module:CloseAssignedNoteTab(slotIndex)
    self:EnsureRuntime()

    local tab = self.runtime.noteSlots and self.runtime.noteSlots[slotIndex]
    if not tab then
        return
    end

    local view = self:GetNoteTabEditView(tab.panel)
    local readView = self:GetNoteTabReadView(tab.panel)
    if view then
        tab.panel.isLoadingView = true
        view.titleInput:SetText("")
        view.bodyInput:SetText("")
        tab.panel.isLoadingView = false
        self:UpdateNoteBodyEditLayout(tab)
    end
    if readView then
        readView.titleText:SetText("")
        self:RefreshNoteReadLineRows(readView, "")
        self:UpdateNoteBodyReadLayout(tab)
    end

    tab.assigned = false
    tab.mode = "edit"
    tab.hasPendingReadItemInfo = false
    tab.pendingReadItemIds = nil
    tab.noteData = nil
    self:SetNoteTabDirty(tab, false)
    self:SetTabTitle(tab, "Note")
    self:RefreshNoteTabControls(tab)
    self:UpdateReadItemInfoEventRegistration()

    if self.runtime.activeTabKey == tab.key then
        self.runtime.activeTabKey = "home"
    end

    self:RefreshTabLayout()
    self:SelectTab(self.runtime.activeTabKey or "home")
end

function module:CloseTab(tab)
    if not tab or not tab.slotIndex then
        return
    end

    self:CloseAssignedNoteTab(tab.slotIndex)
end

function module:CloseTabsForNote(noteId)
    if not noteId or not self.runtime or not self.runtime.noteSlots then
        return
    end

    for slotIndex = 1, MAX_NOTE_TABS do
        local tab = self.runtime.noteSlots[slotIndex]
        if tab and tab.assigned and tab.noteData and tab.noteData.noteId == noteId then
            self:CloseAssignedNoteTab(slotIndex)
        end
    end
end

function module:OpenNote(noteId, openInNewTab, keepCurrentTabActive)
    local note = self:GetNoteById(noteId)
    if not note then
        return false
    end

    self:SetSelectedNote(noteId)

    local existingTab = self:GetOpenTabForNoteId(noteId)
    if existingTab then
        if not keepCurrentTabActive then
            self:SelectTab(existingTab.key)
        end
        return true
    end

    local targetSlotIndex = nil
    if openInNewTab then
        targetSlotIndex = self:GetFirstAvailableNoteTabSlot()
        if not targetSlotIndex then
            self:RefreshRowActionMenu()
            return false
        end
    else
        targetSlotIndex = self:GetFirstAvailableNoteTabSlot() or self:GetFallbackReusableTabSlot()
    end

    self:OpenAssignedNoteTab(targetSlotIndex, note, keepCurrentTabActive)
    return true
end

function module:CreateNotesFrame()
    self:EnsureRuntime()
    if self.runtime.frame then
        return self.runtime.frame
    end

    local frame = CreateFrame("Frame", "SnailStuffNotesFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetFrameStrata("HIGH")
    frame:SetClampedToScreen(true)
    frame:SetMovable(true)
    frame:SetResizable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:Hide()

    if frame.SetMinResize then
        frame:SetMinResize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
    end
    self:UpdateWindowResizeBounds(frame)

    self:ApplyWindowGeometry(frame)

    if frame.TitleText then
        frame.TitleText:SetText(WINDOW_TITLE)
        frame.TitleText:ClearAllPoints()
        frame.TitleText:SetPoint("TOP", frame, "TOP", 0, -4 + WINDOW_TITLE_Y_OFFSET)
    end

    frame:SetScript("OnDragStart", function(selfFrame)
        selfFrame:StartMoving()
    end)
    frame:SetScript("OnDragStop", function(selfFrame)
        selfFrame:StopMovingOrSizing()
        module:SaveWindowGeometry(selfFrame)
    end)
    frame:SetScript("OnHide", function(selfFrame)
        module:SaveWindowGeometry(selfFrame)
        module:HideRowActionMenu()
        module:HideTabContextMenu()
    end)
    frame:SetScript("OnMouseDown", function()
        module:HideRowActionMenu()
        module:HideTabContextMenu()
    end)
    frame:SetScript("OnSizeChanged", function(selfFrame, width, height)
        local clampedWidth, clampedHeight
        if module:IsHomeTabActive() then
            clampedWidth, clampedHeight = ClampHomeWindowSize(width, height)
        else
            clampedWidth, clampedHeight = ClampWindowSize(width, height)
        end
        if not selfFrame.enforcingSize and (math.abs(width - clampedWidth) > 0.5 or math.abs(height - clampedHeight) > 0.5) then
            selfFrame.enforcingSize = true
            selfFrame:SetSize(clampedWidth, clampedHeight)
            selfFrame.enforcingSize = false
            return
        end

        module:SaveWindowGeometry(selfFrame)
        module:RefreshHomeList()
    end)
    frame:SetScript("OnShow", function()
        module:RefreshTabLayout()
        module:SelectTab(module.runtime.activeTabKey or "home")
    end)

    frame.inner = CreateFrame("Frame", nil, frame)
    frame.inner:SetPoint("TOPLEFT", frame, "TOPLEFT", 12, -30)
    frame.inner:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -12, 14)

    frame.innerBackground = frame.inner:CreateTexture(nil, "BACKGROUND")
    frame.innerBackground:SetAllPoints()
    frame.innerBackground:SetTexture("Interface\\Buttons\\WHITE8x8")
    frame.innerBackground:SetVertexColor(0, 0, 0, 0.18)

    frame.contentHost = CreateFrame("Frame", nil, frame.inner)
    frame.contentHost:SetPoint("TOPLEFT", frame.inner, "TOPLEFT", 8, -8)
    frame.contentHost:SetPoint("BOTTOMRIGHT", frame.inner, "BOTTOMRIGHT", -8, 0)

    frame.tabBar = CreateFrame("Frame", nil, frame)
    frame.tabBar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 14, -22)
    frame.tabBar:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -38, -22)
    frame.tabBar:SetHeight(TAB_HEIGHT)
    frame.tabBar:SetFrameStrata(frame:GetFrameStrata())
    frame.tabBar:SetFrameLevel((frame:GetFrameLevel() or 1) + 6)

    frame.resizeGrip = CreateFrame("Button", nil, frame)
    frame.resizeGrip:SetSize(16, 16)
    frame.resizeGrip:SetPoint("BOTTOMRIGHT", -6, 6)
    frame.resizeGrip:RegisterForDrag("LeftButton")
    frame.resizeGrip.texture = frame.resizeGrip:CreateTexture(nil, "ARTWORK")
    frame.resizeGrip.texture:SetAllPoints()
    frame.resizeGrip.texture:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    frame.resizeGrip:SetScript("OnDragStart", function()
        frame.isSizingByGrip = true
        frame:StartSizing("BOTTOMRIGHT")
    end)
    frame.resizeGrip:SetScript("OnDragStop", function()
        if frame.isSizingByGrip then
            frame:StopMovingOrSizing()
        end
        frame.isSizingByGrip = nil
        module:SaveWindowGeometry(frame)
    end)
    frame.resizeGrip:SetScript("OnMouseUp", function(_, button)
        if button ~= "LeftButton" or not frame.isSizingByGrip then
            return
        end

        frame:StopMovingOrSizing()
        frame.isSizingByGrip = nil
        module:SaveWindowGeometry(frame)
    end)

    self.runtime.frame = frame
    self.runtime.tabs = {}
    self.runtime.orderedTabs = {}
    self.runtime.noteSlots = {}
    self.runtime.rowActionMenu = self:CreateRowActionMenu(frame.contentHost)
    self.runtime.tabContextMenu = self:CreateTabContextMenu(frame.contentHost)

    local definitions = {
        { key = "home", title = "Home" },
        { key = "noteSlot1", title = "Note", slotIndex = 1 },
        { key = "noteSlot2", title = "Note", slotIndex = 2 },
        { key = "noteSlot3", title = "Note", slotIndex = 3 },
    }

    for index, definition in ipairs(definitions) do
        local tab = self:CreateTab(frame, definition, index)
        self.runtime.tabs[definition.key] = tab
        self.runtime.orderedTabs[#self.runtime.orderedTabs + 1] = tab

        if definition.slotIndex then
            self.runtime.noteSlots[definition.slotIndex] = tab
        end
    end

    self:RefreshTabLayout()
    self:SelectTab("home")

    return frame
end

function module:OpenWindow()
    if not self:IsOperationalEnabled() then
        SnailStuff:PrintMessage("Notes is disabled. Enable it from Extras first.")
        return
    end

    local frame = self:CreateNotesFrame()
    frame:Show()
    if frame.Raise then
        frame:Raise()
    end
end

function module:IsWindowOpen()
    return self.runtime and self.runtime.frame and self.runtime.frame:IsShown() or false
end

function module:CloseWindow()
    if self.runtime and self.runtime.frame then
        self.runtime.frame:Hide()
    end
end

function module:Refresh()
    self:EnsureRuntime()

    if not self:IsOperationalEnabled() then
        self:CloseWindow()
        return
    end

    if self.runtime.frame and self.runtime.frame:IsShown() then
        self:RefreshHomeView()
        self:RefreshTabLayout()
        self:SelectTab(self.runtime.activeTabKey or "home")
    end

    self:UpdateReadItemInfoEventRegistration()
end

function module:HandleReadItemInfoReceived(itemId, success)
    if not success or not self.runtime or not self.runtime.noteSlots then
        return
    end

    local numericItemId = tonumber(itemId)
    if not numericItemId then
        return
    end

    local didRefreshTab = false
    for _, tab in ipairs(self.runtime.noteSlots) do
        if tab and tab.assigned and not self:IsNoteTabInEditMode(tab) and tab.hasPendingReadItemInfo then
            local pendingReadItemIds = tab.pendingReadItemIds
            if pendingReadItemIds and pendingReadItemIds[numericItemId] then
                self:RefreshNoteReadView(tab)
                didRefreshTab = true
            end
        end
    end

    if not didRefreshTab then
        self:UpdateReadItemInfoEventRegistration()
    end
end

function module:GET_ITEM_INFO_RECEIVED(_, itemId, success)
    self:HandleReadItemInfoReceived(itemId, success)
end

function module:ITEM_DATA_LOAD_RESULT(_, itemId, success)
    self:HandleReadItemInfoReceived(itemId, success)
end

function module:OnInitialize()
    AceSerializer = LibStub and LibStub("AceSerializer-3.0", true) or nil
    LibDeflate = LibStub and LibStub("LibDeflate", true) or nil
    self:EnsureRuntime()
    self:GetNoteStore()
end

function module:OnEnable()
    self:EnsureRuntime()
    self:Refresh()
end

function module:OnDisable()
    if self.runtime and self.runtime.isListeningForReadItemInfo then
        self:UnregisterEvent("GET_ITEM_INFO_RECEIVED")
        self:UnregisterEvent("ITEM_DATA_LOAD_RESULT")
        self.runtime.isListeningForReadItemInfo = false
    end
    self:CloseWindow()
end
